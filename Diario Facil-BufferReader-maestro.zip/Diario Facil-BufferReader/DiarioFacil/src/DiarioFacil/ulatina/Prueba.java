package DiarioFacil.ulatina;

import java.io.*;
import java.sql.Time;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;

public class Prueba {

    static BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
    static PrintStream out = System.out;

    public static void main(String[] args) throws IOException {
        //Declaracion Administrador
        Admin administrador = new Admin(1, "diariofacil", "df", false);
        //Declaracion De DiarioFacil
        DiarioFacil diarioFacil = new DiarioFacil();
        //Declaracion De Listas De DiarioFacil 
        List<Admin> listaAdministrador = new ArrayList<>();
        List<Cliente> listaClientes = new ArrayList<>();
        List<Orden> listaDeOrdenes = new ArrayList<>();
        List<Producto> listaProductos = new ArrayList<>();
        List<Categoria> listaCategorias = new ArrayList<>();
        List<Combo> listaDeCombos=new ArrayList<>();
        List<Proveedor> listaProveedores=new ArrayList<>();
        List<Carrito> listaDeCarrito=new ArrayList<>();
        List<Promocion> listaDePromociones=new ArrayList<>();
        List<ProductoConsumido> listaDeProductosConsumidos=new ArrayList<>();
        
        //Insertar Admin a Lista De Amininistradores
        listaAdministrador.add(administrador);
        //Insertar Listas A Dirario Facil
        diarioFacil.setLstOrden(listaDeOrdenes);
        diarioFacil.setLstAdministradores(listaAdministrador);
        diarioFacil.setLstProductos(listaProductos);
        diarioFacil.setLstCategorias(listaCategorias);
        diarioFacil.setLstProductosConsumidos(listaDeProductosConsumidos);
        diarioFacil.setLstPromociones(listaDePromociones);
        diarioFacil.setLstProveedor(listaProveedores);
        diarioFacil.setLstCliente(listaClientes);
        diarioFacil.setLstCombos(listaDeCombos);

        //Declaracion De Categorias
        Categoria bebidas = new Categoria("Bebidas", listaProductos);
        Categoria carnes = new Categoria("Carnes", listaProductos);
        Categoria harinas = new Categoria("Harinas", listaProductos);
        Categoria frutas = new Categoria("Frutas", listaProductos);
        Categoria verduras = new Categoria("Verduras", listaProductos);
        Categoria juguetes = new Categoria("juguetes", listaProductos);
        
        //Declaracion Productos 
        Producto fresa=new Producto("12", "Fresa", 1000.0, 100, 10, frutas);
        Producto chorizo=new Producto("17", "Chorizo", 2400.50, 25, 5, carnes);
        Producto carrito=new Producto("62", "Carrito", 5000.25, 50, 10, juguetes);
        Producto papa=new Producto("80", "papa", 750.0, 40, 15, verduras);
        Producto pan=new Producto("431", "Pan", 3200.0, 25, 5, harinas);
        Producto galleta=new Producto("653", "Galleta", 1250.75, 75, 10, harinas);
        
        //Declaracion Productos Consumidos
        ProductoConsumido productoConsumidoFresa=new ProductoConsumido(fresa,6);
        ProductoConsumido productoConsumidochorizo=new ProductoConsumido(chorizo,15);
        ProductoConsumido productoConsumidocarrito=new ProductoConsumido(carrito,76);
        ProductoConsumido productoConsumidopapa=new ProductoConsumido(papa,14);
        ProductoConsumido productoConsumidopan=new ProductoConsumido(pan,9);
        ProductoConsumido productoConsumidogalleta=new ProductoConsumido(galleta,98);
        
        //Insertar Productos A Lista De Productos De DiarioFacil
        listaProductos.add(fresa);
        listaProductos.add(chorizo);
        listaProductos.add(carrito);
        listaProductos.add(papa);
        listaProductos.add(pan);
        listaProductos.add(galleta);
        
        //Insertar Categorias A Lista De Categorias De DiarioFacil
        listaCategorias.add(bebidas);
        listaCategorias.add(carnes);
        listaCategorias.add(frutas);
        listaCategorias.add(verduras);
        listaCategorias.add(juguetes);

        //Variables para Correr Programa
        int opc;
        boolean noSalir = true;
        boolean conexion = true;
        //Inicio De Programa
        do {
            //Muestra Menu General Del Sistema
            mostrarMenu();
            //Opcion Elegida Por El Cliente Leida En Este Metodo
            opc = leerOpcion();
            //Enciclado Para Entrar Al Sistema
            noSalir = ejecutarAccionMenuInicio(opc, diarioFacil, listaClientes, conexion, listaProductos, listaCategorias,listaDeCombos,listaProveedores,listaDeCarrito,listaDeOrdenes,listaDePromociones,listaDeProductosConsumidos);

        } while (noSalir == true);
        
		
    }
    //Menu De Inicio General
    public static void mostrarMenu() {
        out.println("\n===========================================================");
        //inicio De Seccion Del Cliente
        out.println("1.  Iniciar Seccion.");
        //Registrarse En El Sistema
        out.println("2.  Registrarse en el Sistema.");
        //Entrar al Sistema Como Administrador
        out.println("3.  Seccion administrativa(solo personal autorizado).");
        //Salir Del Sistema
        out.println("4.  Salir.");
        out.println("===========================================================\n");
    }
    //Pagina De Agregar Producto De Orden
    public static void mostrarMenuAgregarProductoOrden() {
        out.println("\n===========================================================");
        //Agregar Un Nuevo Producto a Carrito
        out.println("1.  Agregar Producto A Orden.");
        //Salir Del Agregado Del Producto En El Carrito de La Orden
        out.println("2.  No Anadir Mas Producto.");
        out.println("===========================================================\n");
    }
    //Pagina De Agregar Promocion A Orden
    public static void mostrarMenuAgregarPromocionAOrden() {
        out.println("\n===========================================================");
        //Agregar Una Nueva Promocion Al Carrito De La Orden
        out.println("1.  Agregar Promocion a Orden.");
        //Salir Del Agregado De la Promocion Del Carrito De La Orden
        out.println("2.  No Anadir Mas Promociones.");
        out.println("===========================================================\n");
    }
    //Pagina De Agregar Combos Al Carrito De Ordenes
    public static void mostrarMenuAgregarComboAOrden() {
        out.println("\n===========================================================");
        //Agregar Un Nuevo Combo Al Carrito De La Orden
        out.println("1.  Agregar Combo a Orden.");
        //Salir Del Agregado Del Combo Del Carrito De La Orden
        out.println("2.  No Anadir Mas Combos.");
        out.println("===========================================================\n");
    }
    //Pagina De Agregar Producto De Combo
    public static void mostrarMenuAgregarProductoProveedores() {
        out.println("\n===========================================================");
        //Agregar Un Nuevo Combo
        out.println("1.  Agregar Producto A Proveedor.");
        //Salir Del Agregado Del Producto En El Combo
        out.println("2.  No Anadir Mas Producto.");
        out.println("===========================================================\n");
    }
    //Pagina De Agregar Producto De Combo
    public static void mostrarMenuAgregarProductoCombo() {
        out.println("\n===========================================================");
        //Agregar Un Nuevo Combo
        out.println("1.  Agregar Producto A Combo.");
        //Salir Del Agregado Del Producto En El Combo
        out.println("2.  No Anadir Mas Producto.");
        out.println("===========================================================\n");
    }
    //Pagina De Agregar Producto A Cliente
    public static void mostrarMenuAgregarProductoCliente() {
        out.println("\n===========================================================");
        //Agregar Un Producto
        out.println("1.  Agregar Producto A Su Carrito.");
        //Salir Del Agregado Del Producto 
        out.println("2.  No Anadir Mas Producto.");
        out.println("===========================================================\n");
    }
        //Pagina De Agregar Combo A Cliente
        public static void mostrarMenuAgregarComboCliente() {
        out.println("\n===========================================================");
        //Agregar Un Combo
        out.println("1.  Agregar Combo A Su Carrito.");
        //Salir Del Agregado Del Combo
        out.println("2.  No Anadir Mas Combos.");
        out.println("===========================================================\n");
    }
        //Pagina De Agregar Promocion A Cliente
            public static void mostrarMenuAgregarPromocionCliente() {
        out.println("\n===========================================================");
        //Agregar Una Promocion
        out.println("1.  Agregar Promocion A Su Carrito.");
        //Salir Del Agregado Del Combo
        out.println("2.  No Anadir Mas Promociones.");
        out.println("===========================================================\n");
    }


    public static void mostrarPaginaCliente(Cliente usuario) {
        //Pagina Unicamente Clientes
        out.println("\n===========================================================");
        //Ver Catalogo De Productos
        out.println("1.  Ver Catalogo.");
        //Ver Carrito De Cliente
        out.println("2.  Ver Carrito.");
        //Ver Todos Los Combos Disponibles
        out.println("3.  Ver Combos.");
        //VerHistorial De Ordenes
        out.println("4.  Ver Historial De Ordenes.");
        //Ver Productos Mas Comprados
        out.println("5.  Ver Productos Mas Comprados.");
        //Visible solo si el Cliente Es Premium y es para Ver Promociones
        if (usuario.getTipoCliente() == true) {
            out.println("6.  Ver Promociones.");
        }
        //Salir Del Menu Del Cliente
        out.println("7.  Salir.");
        out.println("===========================================================\n");
    }

    public static void mostrarPaginaAdministrador() {

        out.println("\n===========================================================");
        //Agregar Promocion
        out.println("1.  Agregar Promocion.");
        //Modificar Promocion
        out.println("2.  Modificar Promocion.");
        //Borrar Promocion
        out.println("3.  Borrar Promocion.");
        //Agregar Producto
        out.println("4.  Agregar Producto.");
        //Modificar Producto
        out.println("5.  Modificar Producto.");
        //Borrar Producto
        out.println("6.  Borrar Producto.");
        //Agregar Combo
        out.println("7.  Agregar Combo.");
        //Modificar Combo
        out.println("8.  Modificar Combo.");
        //Borrar Combo
        out.println("9.  Borrar Combo.");
        //Agregar Proveedor
        out.println("10. Agregar Proovedor.");
        //Modificar Proveedor
        out.println("11. Modificar Proovedor.");
        //Borrar Proveedor
        out.println("12. Borrar Proovedor.");
        //Crear Orden
        out.println("13.  Crear Orden.");
        //Borrar Orden
        out.println("14.  Borrar Orden.");
        //Ver Ordenes
        out.println("15.  Ver Ordenes.");
        //Salir Del Menu Administrador
        out.println("16. Salir.");
        out.println("===========================================================\n");
    }

    public static int leerOpcion() throws java.io.IOException {
        //lee la Opcion Ingresada Por El Usuario
        int opcion;
        out.println("\n===========================================================\n");

        out.print("Seleccione su opción:\n");
        opcion = Integer.parseInt(in.readLine());
        out.println("\n===========================================================\n");

        return opcion;
    }

    public static boolean ejecutarAccionMenuInicio(int opcion, DiarioFacil diarioFacil, List<Cliente> lstCliente, boolean conexion, List<Producto> lstProductos, List<Categoria> lstCategorias,List<Combo> lstCombos,List<Proveedor> lstProveedores,List<Carrito> lstCarritos,List<Orden> lstOrdenes,List<Promocion> lstPromociones,List<ProductoConsumido> lstProductosConsumidos) throws java.io.IOException {
         //Scanner Utilizado Para Leer Dentro De La Consola Segun El tipo De Dato Sea Necesario
        Scanner sc=new Scanner(System.in);
        //entero Para Guardar La Opcion Elegida Por El Cliente
        int opc;
        boolean noSalir = true;
        int numProd = opcion;

        switch (numProd) {

            case 1: //Opcion Ingresar en el sistema como cliente
                Cliente usuario = new Cliente();
                out.print("\nIngrese su nombre de usuario\n");
                String nombre = sc.next();
                out.print("Ingrese su contrasena\n");
                String contrasena =sc.next();

                usuario = Cliente.inicioSeccion(diarioFacil, nombre, contrasena);
                if (usuario != null) {

                    conexion = true;
                    do {
                        mostrarPaginaCliente(usuario);
                        opc = leerOpcion();
                        ejecutarAccionPaginaCliente(opc, usuario, diarioFacil,lstProductos,lstCarritos,lstCombos,lstPromociones,lstProductosConsumidos,lstOrdenes);
                    } while (conexion == true);
                }
                break;

            case 2:// Registrarse Como Cliente

                lstCliente.add(Cliente.Registrarse());
                diarioFacil.setLstCliente(lstCliente);
                break;

            case 3:// Entrar Al Sistema Como Administrador
                Admin administrador = new Admin();
                out.print("\nIngrese Nombre De Administrador\n");
                String nombreAdmin = sc.next();
                out.print("Ingrese contraseña de administrador\n");
                String contrasenaAdmin = sc.next();
                administrador = Admin.inicioSeccionAdministrador(diarioFacil, nombreAdmin, contrasenaAdmin);

                if (administrador.login == true) {
                    conexion = true;
                    do {
                        mostrarPaginaAdministrador();
                        opc = leerOpcion();
                        conexion=ejecutarAccionPaginaAdministrador(opc, diarioFacil, lstProductos, lstCategorias,lstCombos,lstProveedores,lstCarritos,lstCliente,lstOrdenes,lstPromociones);
                    } while (conexion == true);
                }

                break;
            case 4://Salir del sistema por completo

                noSalir = false;

                break;

            default: //Cualquier otro valor dado por el usuario se considera inválido

                out.println("Opcion inválida");
                out.println();
                break;
        }
        return noSalir;
    }
    
//Ejecucion De Pagina Cliente,Ejecutara La Orden Deseada Por El Cliente.
    public static boolean ejecutarAccionPaginaCliente(int opcion, Cliente cliente, DiarioFacil diariofacil,List<Producto> lstProductos,List<Carrito> lstCarritos,List<Combo> lstTodosLosCombos,List<Promocion> lstTodaslasPromociones,List<ProductoConsumido> lstTodosLosProductosConsumidos,List<Orden> lstOrden) throws java.io.IOException {
        //booleano para verificar la conexion Del Cliente Dentro Del Sistema
        boolean conexion = true;
        //entero que va a Guardar la opcion Elegida Por El Cliente
        int numProd = opcion;
        //Declaracion De Listas Del Carrito Del Cliente
        List<Producto> lstProductosCarritoCliente=new ArrayList<>();
        List<Promocion> lstPromocionesCarritoCliente=new ArrayList<>();
        List<Combo> lstComboCarritoCliente=new ArrayList<>();
        //Declaracion Del Carrito Del Cliente Y Agregacion De Listas
        Carrito carritoCliente=new Carrito(cliente,lstProductosCarritoCliente,lstPromocionesCarritoCliente,lstComboCarritoCliente);
        //Declaracion De Orden Cliente
        Orden ordenCliente=new Orden();
        //Agrega Carrito A Orden De Cliente
        ordenCliente.setCarrito(carritoCliente);
        //Agrega La Orden De Cliente A la Lista De Ordenes De DiarioFacil
        lstOrden.add(ordenCliente);
        
        //Opciones Del Cliente
        switch (numProd) {
            
            case 1: //Opcion Ver catalogo Productos y Anadir Productos A Carrito Del Respectivo Cliente
                //booleano Para Ciclo De Agregar Producto A Carrito
                boolean agregarProductoCliente=true;
                //Imprime Todos Los Productos Disponibles
                for (Producto p : lstProductos) {
                    out.print("\n"+p.getNombreProducto());
                }
                //Imprime Menu De Opciones Del Cliente
                mostrarMenuAgregarProductoCliente();
                //Ciclo Para Agregar Productos A La Lista De Clientes
                do{
                    //Agrega Producto Al Carrito Del Respectivo Cliente
                    agregarProductoCliente=ejecutarAccionAgregarProductoCliente(leerOpcion(), lstProductos, lstProductosCarritoCliente);
                }while(agregarProductoCliente==true);
                //Se llama El metodo Acumulado De los Precios Del Carrito
                ordenCliente.getTotalOrden(lstProductos, lstPromocionesCarritoCliente, lstComboCarritoCliente);
                break;

            case 2:// Opcion Ver carrito Cliente
                System.out.println(Cliente.getCarritoCliente(lstCarritos, cliente));
                break;

            case 3:// Opcion Ver combos y Agregar Combos Al Carrito Cliente
                //booleano Para El ciclo De Agregar Combo A Carrito Cliente
            boolean agregarComboCliente=true;
            //Imprime Todos Los Combos Disponibles y sus Productos Respectivos
                for (Combo c : lstTodosLosCombos) {
                    out.print("\n"+c.getIdCombo()+c.getLstProductosCombo());
                }
                //Imprime Las Opciones De Agregar Combos Al Carrito Cliente
                mostrarMenuAgregarComboCliente();
                //Ciclo Para Agregar Combo A Carrito Cliente
                do{
                    //Agregar Combo Al Carrito Del Cliente
                    agregarComboCliente=ejecutarAccionAgregarComboCliente(leerOpcion(), lstTodosLosCombos, lstComboCarritoCliente);
                }while(agregarComboCliente==true);
                //Se llama El metodo Acumulado De los Precios Del Carrito
                ordenCliente.getTotalOrden(lstProductos, lstPromocionesCarritoCliente, lstComboCarritoCliente);
                break;

            case 4:// Opcion Ver Historial De Compras Del Cliente Respectivo
                Cliente.getOrdenesCliente(diariofacil, cliente);
                break;

            case 5:// Opcion Ver Productos Mas Comprados
                int auxCounter=0;
            
               // Collections.sort(lstTodosLosProductosConsumidos.iterator());
                
                break;
            case 6:// Opcion Ver Promociones(Solo Premium) 
                //verifica El tipo De Cliente Con El que se Esta Tratando
                if(cliente.getTipoCliente()==true){
                    //booleano Par Entrar En El Ciclo De Agregar Promocion A Carrito Cliente
                    boolean agregarPromocionCliente=true;
                    //Muestra Todas Las Promociones Disponibles Hasta El Momento
                for (Promocion p : lstTodaslasPromociones) {
                    out.print("\n"+p.getProductoPromocion().getNombreProducto());
                }
                //Imprime El Menu De Agregar Promocion Al Carrito Cliente
                mostrarMenuAgregarPromocionCliente();
                //Ciclo de Agregar Promociones Al carrito De Cliente
                do{
                    //Opciones Para Agregar Promociones A Carrito Cliente
                    agregarPromocionCliente=ejecutarAccionAgregarPromocionCliente(leerOpcion(), lstPromocionesCarritoCliente, lstTodaslasPromociones);
                }while(agregarPromocionCliente==true);
                //Se llama El metodo Acumulado De los Precios Del Carrito
                ordenCliente.getTotalOrden(lstProductos, lstPromocionesCarritoCliente, lstComboCarritoCliente);
                }
                break;
            case 7:// Salir 
                //lo Devuelve Al Menu General
                conexion = false;
                //Se Deslogea La conexion De Cliente
                cliente.setLogin(false);
                //anade el carrito a la lista de Carritos Antes de Irse
                lstCarritos.add(carritoCliente);

                break;

            default: //Cualquier otro valor dado por el usuario se considera inválido

                out.println("Opcion inválida");
                out.println();
                break;
        }
        //retorna El booleano ya Sea true o False
        return conexion;
    }
    //Opciones Del Cliente Enciclada Para Agregar Combo Al Carrito Del Cliente
    public static boolean ejecutarAccionAgregarComboCliente(int opcion,List<Combo> lstTodosLosCombos,List<Combo> lstComboCliente) throws java.io.IOException {
        //Scanner Utilizado Para Leer Dentro De La Consola Segun El tipo De Dato Sea Necesario
        Scanner sc=new Scanner(System.in);
        //boleano usado Para Enciclar El Agregar Combo Al Carrito del Cliente
        boolean ingresoProducto = true;
        //Entero Usado Para Ver La Opcion Elegida Por El Cliente
        int numProd = opcion;
        //Opciones Elegidas Por El Cliente
        switch (numProd) {

            case 1: //Opcion Ingresar Combo Del Cliente Deseado
                out.print("Ingrese el Nombre Del Producto Que Desea Agregar.");
                String nombreComboSeleccionado=sc.next();
                lstComboCliente.add(Cliente.getComboCliente(nombreComboSeleccionado,lstTodosLosCombos));
                break;
            case 2://Salir del Agregado Del Combo

                ingresoProducto = false;

                break;

            default: //Cualquier otro valor dado por el Administrador se considera inválido

                out.println("Opcion inválida");
                out.println();
                break;
        }
        //retorna El booleano ya Sea true o False
        return ingresoProducto;
    }
    //Opciones Del Cliente Enciclada Para Agregar Promocion Al Carrito Del Cliente
    public static boolean ejecutarAccionAgregarPromocionCliente(int opcion,List<Promocion> lstTodasLasPromociones,List<Promocion> lstPromocionesCarritoCliente) throws java.io.IOException {
        //Scanner Utilizado Para Leer Dentro De La Consola Segun El tipo De Dato Sea Necesario
        Scanner sc=new Scanner(System.in);
        //boleano usado Para Enciclar El Agregar Promocion Al Carrito del Cliente
        boolean ingresoProducto = true;
        //Entero Usado Para Ver La Opcion Elegida Por El Cliente
        int numProd = opcion;
        //Opciones Elegidas Por El Cliente
        switch (numProd) {

            case 1: //Opcion Ingresar Promocion Del Cliente Deseado
                out.print("Ingrese el Nombre De La Promocion Que Desea Agregar.");
                String nombrePromocionSeleccionado=sc.next();
                lstPromocionesCarritoCliente.add(Cliente.getPromocionCliente(nombrePromocionSeleccionado,lstTodasLasPromociones));
                break;
            case 2://Salir del Agregado De Promocion

                ingresoProducto = false;

                break;

            default: //Cualquier otro valor dado por el Administrador se considera inválido

                out.println("Opcion inválida");
                out.println();
                break;
        }
        //retorna El booleano ya Sea true o False
        return ingresoProducto;
    }
    //Opciones Del Cliente Enciclada Para Agregar Producto Al Carrito Del Cliente
    public static boolean ejecutarAccionAgregarProductoCliente(int opcion,List<Producto> lstTodosLosProductos,List<Producto> lstProductoDeCliente) throws java.io.IOException {
        //Scanner Utilizado Para Leer Dentro De La Consola Segun El tipo De Dato Sea Necesario
        Scanner sc=new Scanner(System.in);
        //boleano usado Para Enciclar El Agregar Producto Al Carrito del Cliente
        boolean ingresoProducto = true;
        //Entero Usado Para Ver La Opcion Elegida Por El Cliente
        int numProd = opcion;
        //Opciones Elegidas Por El Cliente
        switch (numProd) {

            case 1: //Opcion Ingresar Producto Al Carrito 
                out.print("Ingrese el Nombre Del Producto Que Desea Agregar.");
                String nombreProductoSeleccionado=sc.next();
                lstProductoDeCliente.add(Cliente.getProductoCliente(nombreProductoSeleccionado,lstTodosLosProductos));
                break;
            case 2://Salir del Agregado Del Producto

                ingresoProducto = false;

                break;

            default: //Cualquier otro valor dado por el Administrador se considera inválido

                out.println("Opcion inválida");
                out.println();
                break;
        }
        return ingresoProducto;
    }

    public static boolean ejecutarAccionPaginaAdministrador(int opcion, DiarioFacil diarioFacil, List<Producto> lstProductos, List<Categoria> lstCategorias,List<Combo> lstCombos,List<Proveedor> lstProveedores,List<Carrito> lstCarritos,List<Cliente> lstClientes,List<Orden> lstOrdenes,List<Promocion> lstPromociones) throws java.io.IOException {
        Scanner scan = new Scanner(System.in);
        boolean conexion = true;
        int numProd = opcion;
        DiarioFacil df = new DiarioFacil();

        switch (numProd) {

            case 1: //Agregar Promocion
            out.print("\n===========================================================\n");
                out.print("Ingrese el descuento de la Promoción\n");
                Double precioPromo = scan.nextDouble();
                out.print("\n===========================================================\n"); 
                out.print("Estos son los productos existentes");
                for (Producto p : diarioFacil.getLstProductos()){
                    out.print("\n" + p.getNombreProducto());
                }
                out.print("\n===========================================================\n");                
                out.print("\nSeleccione el Producto en promoción\n");
                String productoExistente = in.readLine();
                out.print("\n===========================================================\n");
                
                if (Producto.getProductoSeleccionado(diarioFacil, productoExistente)!= null){
                    lstPromociones.add(Admin.agregarPromocion(Producto.getProductoSeleccionado(diarioFacil, productoExistente), precioPromo));
                    out.println("\n¡Combo creado con éxito!");
                }else{
                    out.println("Por favor intente de nuevo");
                }  
                break;

            case 2:// Modificar Promocion
                out.print("\n===========================================================\n");
                out.print("Estos son las promociones existentes y sus precios con descuento:");
                for(Promocion p : diarioFacil.getLstPromociones()){
                    out.print("\n" + p.getProductoPromocion().getNombreProducto() + " " + (p.getProductoPromocion().getPrecioProducto()-p.getProductoPromocion().getPrecioProducto()*p.getDescuento()));
                }
                out.print("\n===========================================================\n");                
                out.print("\nSeleccione la promoción a modificar\n");
                String promoExistente = in.readLine();
                out.print("\n===========================================================\n");
                out.println("\nIngrese el nuevo descuento de la Promoción:");
                Double nuevoDescuento = scan.nextDouble();
                if (Promocion.getPromocionOrdenCarrito(promoExistente, lstPromociones) != null){
                    Promocion.getPromocionOrdenCarrito(promoExistente, lstPromociones).setDescuento(nuevoDescuento);
                    out.println("\n¡Promoción modificada con éxito!");
                }

                break;

            case 3:// Borrar Promocion
            out.print("\n===========================================================\n");
                out.print("Estos son las promociones existentes y sus precios con descuento:");
                for(Promocion p : diarioFacil.getLstPromociones()){
                    out.print("\n" + p.getProductoPromocion().getNombreProducto() + " " + p.getProductoPromocion().getPrecioProducto()*p.getDescuento());
                }
                 out.print("\n===========================================================\n");                
                out.print("\nSeleccione la promoción a borrar, o presione Enter para Cancelar\n");
                String promoBorrar = in.readLine();
                if (Promocion.getPromocionOrdenCarrito(promoBorrar, lstPromociones) != null){
                    lstPromociones.remove(Promocion.getPromocionOrdenCarrito(promoBorrar, lstPromociones));
                    out.println("Promoción " + promoBorrar.toString() + " borrada...");
                }
                break;

            case 4:// Agregar Producto
                out.print("\n===========================================================\n");
                out.print("Ingresar un nuevo producto");
                out.println("\nIngrese el ID del producto");
                String id = scan.next();
                out.println("Ingrese el nombre del producto");
                String nombre = scan.next();
                out.println("Ingrese el precio del producto");
                Double precio = scan.nextDouble();
                out.println("Ingrese el inventario del producto");
                Integer inventario = scan.nextInt();
                out.println("Ingrese el Stock Mínimo del producto");
                Integer stock = scan.nextInt();
                for (Categoria c : diarioFacil.getLstCategorias()) {
                    out.print("\n"+c.getCategoria());
                }
                out.println("\nIngrese la Categoría Deseada.");
                String categoriaElegida = in.readLine();

                out.print("===========================================================\n");

                if (Categoria.getCategoriaSeleccionada(diarioFacil, categoriaElegida) != null) {
                    lstProductos.add(Admin.agregarProducto(id, nombre, precio, inventario, stock, Categoria.getCategoriaSeleccionada(diarioFacil, categoriaElegida)));

                    out.print("Producto Agregado Con Exito.");
                } else {
                    out.print("Error, Por Favor Intentelo De Nuevo.");
                }
                break;

            case 5:// Modificar Producto 
                
                out.print("\n===========================================================\n");
                out.print("Estos son los Productos Existentes:");
                for(Producto p : diarioFacil.getLstProductos()){
                    out.print("\n" + p.getNombreProducto());
                }
                out.print("\n===========================================================\n");                
                out.print("\nSeleccione El Producto a Modificar\n");
                String productoExistenteAModificar = in.readLine();
                out.print("\n===========================================================\n");
                out.println("\nIngrese el nuevo Precio Del Producto:");
                Double nuevoPrecio = scan.nextDouble();
                out.println("\nIngrese el nuevo Inventario Del Producto:");
                int nuevoInventarioProducto = scan.nextInt();
                out.println("\nIngrese el nuevo Inventario Minimo Del Producto:");
                int nuevoInventarioMinimoProducto = scan.nextInt();
                
                if (Producto.getProductoSeleccionado(diarioFacil, productoExistenteAModificar) != null){
                    Producto.getProductoSeleccionado(diarioFacil, productoExistenteAModificar).setPrecioProducto(nuevoPrecio);
                    Producto.getProductoSeleccionado(diarioFacil, productoExistenteAModificar).setInventarioActual(nuevoInventarioProducto);
                    Producto.getProductoSeleccionado(diarioFacil, productoExistenteAModificar).setStockMinimo(nuevoInventarioMinimoProducto);
                    
                    out.println("\n¡Producto modificado con éxito!");
                }

                break;

            case 6: //Borrar Producto
                out.print("\n===========================================================\n");
                out.print("Estos son los Productos Existentes:");
                for(Producto p : diarioFacil.getLstProductos()){
                    out.print("\n" + p.getNombreProducto());
                }
                out.print("\n===========================================================\n");                
                out.print("\nSeleccione El Producto a Borrar, o presione Enter para Cancelar\n");
                String productoBorrar = in.readLine();
                out.print("\n===========================================================\n");
                
                if(Producto.getProductoSeleccionado(diarioFacil, productoBorrar) != null){
                    lstProductos.remove(Producto.getProductoSeleccionado(diarioFacil, productoBorrar));
                    out.println("Producto " + productoBorrar.toString() + " borrado...");
                }

                break;

            case 7: // Agregar Combo
                boolean ingresoProducto=true;
                List<Producto> lstProductoCombo=new ArrayList();
                
                out.print("\n===========================================================\n");
                out.print("Ingresar un nuevo Combo:\n");
                out.println("\nIngrese el ID del Combo:\n");
                String idCombo = scan.next();
                for (Producto p : lstProductos) {
                    System.out.println("\n"+p.getNombreProducto());
                }
                do{
                    mostrarMenuAgregarProductoCombo();
                   ingresoProducto=ejecutarAccionAgregarProductoCombo(leerOpcion(),lstProductos,lstProductoCombo);
                }while(ingresoProducto==true);
                
                out.println("Ingrese el precio del Combo:\n");
                Double precioCombo = scan.nextDouble();

                out.print("===========================================================\n");
                lstCombos.add(Admin.agregarCombo(idCombo, precioCombo, lstProductoCombo));
                break;

            case 8: //Modificar Combo
                out.print("\n===========================================================\n");
                out.print("Estos son los Combos existentes y sus precios:");
                for(Combo c : diarioFacil.getLstCombos()){
                    out.print(c.getIdCombo());
                    for(Producto p : c.getLstProductosCombo()){
                        out.println(p.getNombreProducto());
                    }
                    
                }
                out.print("\n===========================================================\n");                
                out.print("\nSeleccione el Combo a modificar\n");
                String ComboExistente = in.readLine();
                out.print("\n===========================================================\n");
                out.println("\nIngrese el nuevo precio del Combo:");
                Double nuevoPrecioCombo = scan.nextDouble();
                if (Combo.getComboCarrito(ComboExistente, lstCombos) != null){
                    Combo.getComboCarrito(ComboExistente, lstCombos).setPrecioCombo(nuevoPrecioCombo);
                    out.println("\n¡Combo modificado con éxito!");
                }
                break;

            case 9: //Borrar Combo
                out.print("\n===========================================================\n");
                out.print("Estos son los Combos Existentes:");
                for(Combo c : diarioFacil.getLstCombos()){
                     out.print(c.getIdCombo());
                    for (Producto p : c.getLstProductosCombo()) {
                        out.println(p.getNombreProducto());
                    }
                }
                out.print("\n===========================================================\n");                
                out.print("\nSeleccione el ID del Combo a borrar, o presione Enter para Cancelar\n");
                String comboBorrar = in.readLine();
                out.print("\n===========================================================\n");
                
                if(Combo.getComboCarrito(comboBorrar, lstCombos) != null){
                    lstCombos.remove(Combo.getComboCarrito(comboBorrar, lstCombos));
                    out.println("Combo con el ID " + comboBorrar.toString() + " borrado...");
                }

                break;

            case 10: //Agregar Proovedor
                boolean ingresoProductoProveedor=true;
                List<Producto> lstProductoProveedor=new ArrayList();
                
                out.print("\n===========================================================\n");
                out.print("Ingresar un nuevo Proveedor.\n");
                out.println("\nIngrese el ID Del Proveedor:\n");
                String idProveedor = scan.next();
                out.println("\nIngrese el Nombre Del Proveedor:\n");
                String nombreProveedor = scan.next();
                out.println("\nIngrese el Correo Del Proveedor:\n");
                String correoProveedor = scan.next();
                out.println("\nIngrese el Telefono Del Proveedor:\n");
                String telefonoProveedor = scan.next();
                out.println("\nIngrese La Direccion Del Proveedor:\n");
                String direccionProveedor = scan.next();
                for (Producto p : lstProductos) {
                    System.out.println("\n"+p.getNombreProducto());
                }
                do{
                    mostrarMenuAgregarProductoProveedores();
                   ingresoProducto=ejecutarAccionAgregarProductoProveedor(leerOpcion(),lstProductos,lstProductoProveedor);
                }while(ingresoProducto==true);

                out.print("===========================================================\n");
                lstProveedores.add(Admin.agregarProveedor(idProveedor, nombreProveedor, correoProveedor, direccionProveedor, telefonoProveedor, lstProductoProveedor));

                break;

            case 11: //Modificar Proovedor
                out.print("\n===========================================================\n");
                out.print("Estos son los Proveedores Existentes:");
                for(Proveedor p : diarioFacil.getLstProveedor()){
                    out.print("\n" + p.getNombreProveedor());
                }
                out.print("\n===========================================================\n");                
                out.print("\nSeleccione El Proveedor a Modificar\n");
                String proveedorExistenteModificar = in.readLine();
                out.print("\n===========================================================\n");
                out.println("\nIngrese el nuevo Correo Del Proveedor:");
                String nuevoCorreo = scan.next();
                out.println("\nIngrese el nuevo Telefono Del Proveedor:");
                String nuevoTelefono = scan.next();
                out.println("\nIngrese la nueva Direccion Del Proveedor:");
                String nuevaDireccion = scan.next();
                
                if (Proveedor.getProveedorModificar(proveedorExistenteModificar, lstProveedores) != null){
                    Proveedor.getProveedorModificar(proveedorExistenteModificar, lstProveedores).setCorreoProveedor(nuevoCorreo);
                    Proveedor.getProveedorModificar(proveedorExistenteModificar, lstProveedores).setTelefonoProveedor(nuevoTelefono);
                    Proveedor.getProveedorModificar(proveedorExistenteModificar, lstProveedores).setDireccionProveedor(nuevaDireccion);
                    
                    out.println("\n¡Proveedor modificado con éxito!");
                }

                break;

            case 12: //Borrar Proovedor

                break;
            case 13: //Crear Orden
                
                boolean ingresoProductoOrden=true;
                boolean ingresoPromocionOrden=true;
                boolean ingresoComboOrden=true;
                Cliente clienteOrden=null;
                Carrito carritoOrden=new Carrito();
                List<Producto> lstProductoOrdenCarrito=new ArrayList<>();
                List<Promocion> lstPromocionOrdenCarrito=new ArrayList<>();
                List<Combo> lstComboOrdenCarrito=new ArrayList<>();
                carritoOrden.setLstProductosCarrito(lstProductoOrdenCarrito);
                carritoOrden.setLstPromocionesCarrito(lstPromocionOrdenCarrito);
                carritoOrden.setLstCombosCarrito(lstComboOrdenCarrito);
                out.print("\n===========================================================\n");
                out.print("Ingresar una Nueva Orden.\n");
                out.println("\nIngrese el ID De La Orden:\n");
                int idOrden = scan.nextInt();
                out.println("\nIngrese el Nombre Del Cliente:\n");
                String nombreClienteOrden = scan.next();
                for(Cliente c:lstClientes){
                    if(nombreClienteOrden.equals(c.name)==true){
                        clienteOrden=c;
                    }
                }
                carritoOrden.setCarritoCliente(clienteOrden);
                Time fechaCreacionDeOrden=Time.valueOf(LocalTime.MIN);
                out.print("===========================================================\n");
                out.print("Productos A Agregar:\n");
                for (Producto p : lstProductos) {
                    out.println(p.getNombreProducto());
                }
                out.print("===========================================================\n");
                do{
                    mostrarMenuAgregarProductoOrden();
                   ingresoProductoOrden=ejecutarAccionAgregarProductoOrdenCarrito(leerOpcion(),lstProductos,lstProductoOrdenCarrito);
                }while(ingresoProductoOrden==true);
                out.print("===========================================================\n");
                out.print("\nProductos En Promocion A Agregar:");
                for (Promocion p : lstPromociones) {
                    out.print("\n"+p.getProductoPromocion().getNombreProducto());
                }
                out.print("===========================================================\n");
                do{
                    mostrarMenuAgregarPromocionAOrden();
                   ingresoPromocionOrden=ejecutarAccionAgregarPromocionOrdenCarrito(leerOpcion(), lstPromociones, lstPromocionOrdenCarrito);
                }while(ingresoPromocionOrden==true);
                out.print("===========================================================\n");
                out.print("\nCombos A Agregar:");
                for (Combo c : lstCombos) {
                    out.print("\n"+c.getIdCombo()+"\n"+c.getLstProductosCombo());
                }
                out.print("===========================================================\n");
                do{
                    mostrarMenuAgregarComboAOrden();
                   ingresoComboOrden=ejecutarAccionAgregarComboOrdenCarrito(leerOpcion(),lstCombos,lstComboOrdenCarrito);
                }while(ingresoComboOrden==true);
                System.out.println("Ingrese El Total De La Orden:\n");
                Double totalOrden=scan.nextDouble();
                Orden nuevaOrden=new Orden(idOrden, clienteOrden, fechaCreacionDeOrden, totalOrden, carritoOrden);
                lstOrdenes.add(nuevaOrden);

                out.print("===========================================================\n");

                break;
            case 14: //Borrar Orden

                break;
            case 15: //Ver Ordenes
                for (Orden o : lstOrdenes) {
                    out.print(o);
                }

                break;
            case 16: //Salir
                conexion = false;
                break;

            default: //Cualquier otro valor dado por el usuario se considera inválido

                out.println("Opcion inválida");
                out.println();
                break;
        }
        return conexion;
    }
     public static boolean ejecutarAccionAgregarProductoCombo(int opcion,List<Producto> lstTodosLosProductos,List<Producto> lstProductoDeCombo) throws java.io.IOException {
        int opc;
        boolean ingresoProducto = true;
        int numProd = opcion;

        switch (numProd) {

            case 1: //Opcion Ingresar en el sistema como cliente
                out.print("Ingrese el Nombre Del Producto Que Desea Agregar.");
                String nombreProductoSeleccionado=in.readLine();
                for (Producto p : lstTodosLosProductos) {
                    if(nombreProductoSeleccionado.equals(p.getNombreProducto())==true){
                        lstProductoDeCombo.add(Combo.getProductoCombo(nombreProductoSeleccionado, lstProductoDeCombo));
                    }
                }
                break;
            case 2://Salir del Agregado Del Producto A Combos

                ingresoProducto = false;

                break;

            default: //Cualquier otro valor dado por el Administrador se considera inválido

                out.println("Opcion inválida");
                out.println();
                break;
        }
        return ingresoProducto;
    }
     public static boolean ejecutarAccionAgregarProductoProveedor(int opcion,List<Producto> lstTodosLosProductos,List<Producto> lstProductoDeProveedor) throws java.io.IOException {
        Scanner sc=new Scanner(System.in);
         int opc;
        boolean ingresoProducto = true;
        int numProd = opcion;

        switch (numProd) {

            case 1: //Opcion Ingresar en el sistema como cliente
                out.print("Ingrese el Nombre Del Producto Que Desea Agregar.");
                String nombreProductoSeleccionado=sc.next();
                for (Producto p : lstTodosLosProductos) {
                    if(nombreProductoSeleccionado.equals(p.getNombreProducto())==true){
                        lstProductoDeProveedor.add(Proveedor.getProductoProveedor(nombreProductoSeleccionado, lstProductoDeProveedor));
                    }
                }
                break;
            case 2://Salir del Agregado Del Producto A Combos

                ingresoProducto = false;

                break;

            default: //Cualquier otro valor dado por el Administrador se considera inválido

                out.println("Opcion inválida");
                out.println();
                break;
        }
        return ingresoProducto;
    }
     public static boolean ejecutarAccionAgregarProductoOrdenCarrito(int opcion,List<Producto> lstTodosLosProductos,List<Producto> lstProductoDeOrdenCarrito) throws java.io.IOException {
        Scanner sc=new Scanner(System.in);
        int opc;
        boolean ingresoProductoOrdenCarrito = true;
        int numProd = opcion;

        switch (numProd) {

            case 1: //Opcion Ingresar en el sistema como cliente
                out.print("Ingrese el Nombre Del Producto Que Desea Agregar.\n");
                String nombreProductoSeleccionado=sc.next();
                for (Producto p : lstTodosLosProductos) {
                    if(nombreProductoSeleccionado.equals(p.getNombreProducto())==true){
                        lstProductoDeOrdenCarrito.add(Orden.getProductoOrden(nombreProductoSeleccionado,lstTodosLosProductos));
                    }
                }
                break;
            case 2://Salir del Agregado Del Producto A Combos

                ingresoProductoOrdenCarrito = false;

                break;

            default: //Cualquier otro valor dado por el Administrador se considera inválido

                out.println("Opcion inválida");
                out.println();
                break;
        }
        return ingresoProductoOrdenCarrito;
    }
     public static boolean ejecutarAccionAgregarPromocionOrdenCarrito(int opcion,List<Promocion> lstTodasLasPromociones,List<Promocion> lstPromocinesDeCarritoOrden) throws java.io.IOException {
        Scanner sc=new Scanner(System.in);
         int opc;
        boolean ingresoPromocionOrdenCarrito = true;
        int numProd = opcion;

        switch (numProd) {

            case 1: //Opcion Ingresar en el sistema como cliente
                out.print("Ingrese el Nombre Del Producto En Promocion Que Desea Agregar.\n");
                String nombrePromocionSeleccionado=sc.next();
                for (Promocion p : lstTodasLasPromociones) {
                    if(nombrePromocionSeleccionado.equals(p.getProductoPromocion().getNombreProducto())==true){
                        lstPromocinesDeCarritoOrden.add(Promocion.getPromocionOrdenCarrito(nombrePromocionSeleccionado,lstTodasLasPromociones));
                    }
                }
                break;
            case 2://Salir del Agregado Del Producto A Combos

                ingresoPromocionOrdenCarrito = false;

                break;

            default: //Cualquier otro valor dado por el Administrador se considera inválido

                out.println("Opcion inválida");
                out.println();
                break;
        }
        return ingresoPromocionOrdenCarrito;
    }
     public static boolean ejecutarAccionAgregarComboOrdenCarrito(int opcion,List<Combo> lstTodosLosCombos,List<Combo> lstCombosDeCarritoOrden) throws java.io.IOException {
        Scanner sc=new Scanner(System.in);
         int opc;
        boolean ingresoComboOrdenCarrito = true;
        int numProd = opcion;

        switch (numProd) {

            case 1: //Opcion Agregar Combo Al Carrito De Nueva Orden
                out.print("Ingrese el Id Del Combo Que Desea Agregar.");
                String nombreIdComboSeleccionado=sc.next();
                for (Combo c : lstTodosLosCombos) {
                    if(nombreIdComboSeleccionado.equals(c.getIdCombo())==true){
                        lstCombosDeCarritoOrden.add(Combo.getComboCarrito(nombreIdComboSeleccionado, lstTodosLosCombos));
                    }
                }
                
                break;
            case 2://Salir del Agregado De Combos

                ingresoComboOrdenCarrito = false;

                break;

            default: //Cualquier otro valor dado por el Administrador se considera inválido

                out.println("Opcion inválida");
                out.println();
                break;
        }
        return ingresoComboOrdenCarrito;
    }
     

}


