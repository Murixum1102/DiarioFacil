package DiarioFacil.ulatina;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Cliente extends Usuario {

    private Boolean tipoCliente;
    private Integer cantidadCompras;

    public Cliente() {

    }

   

    public Cliente(Boolean tipoCliente, Integer cantidadCompras, Integer id,String name, String password, Boolean login) {
        super(id, name, password, login);
        this.tipoCliente = tipoCliente;
        this.cantidadCompras = cantidadCompras;
    }

    public Boolean getTipoCliente() {
        return tipoCliente;
    }

    public void setTipoCliente(Boolean tipoCliente) {
        this.tipoCliente = tipoCliente;
    }

    public Integer getCantidadCompras() {
        return cantidadCompras;
    }

    public void setCantidadCompras(Integer cantidadCompras) {
        this.cantidadCompras = cantidadCompras;
    }
    

    @Override
    public String toString() {
        StringBuffer sb=new StringBuffer();
        sb.append("=============================================================================\n");
        sb.append("Id: "+this.id);
        sb.append("\n");
        sb.append("Nombre: "+this.name);
        sb.append("\n");
        sb.append("Contrasena: *******");
        sb.append("\n");
        sb.append("Estado de conexion: "+this.login);
        sb.append("\n");
        sb.append("Cantidad De Compras: "+this.cantidadCompras);
        sb.append("\n=============================================================================");
        return   sb.toString();
    }

   
  

    public static Cliente Registrarse() throws IOException {

        Cliente usuario = new Cliente();

        System.out.println("Digite sus primeros tres digitos de la cedula:\n");
        usuario.id = System.in.read();

        System.out.println("Digite su nombre de usuario:\n");
        usuario.name = System.in.toString();
        
        System.out.println("Digite su contrasena:\n");
        usuario.password = System.in.toString();
        
        usuario.login = false;

        System.out.println("==================================================\n");
        System.out.println("Se a registrado con exito.\n");
        System.out.println("==================================================\n");

        return usuario;
    }

}
