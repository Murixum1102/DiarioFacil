/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DiarioFacil.ulatina;
import java.util.List;

/**
 *
 * @author murip
 */
public class Carrito {
    private List<Producto> LstProductosCarrito;
    private List<Promocion> LstPromocionesCarrito;
    private List<Combo> LstCombosCarrito;
}
