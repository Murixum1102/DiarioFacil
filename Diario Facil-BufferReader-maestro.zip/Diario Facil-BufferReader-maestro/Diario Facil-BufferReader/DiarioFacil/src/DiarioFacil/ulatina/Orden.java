package DiarioFacil.ulatina;

import java.sql.Time;
import java.util.List;

public class Orden {

    private Integer idOrden;
    private Cliente cliente;
    private Time fechaOrden;
    private Double totalOrden;
    private Carrito carrito;

    public Orden() {

    }

    public Orden(Integer idOrden, Cliente cliente, Time fechaOrden, Double totalOrden, Carrito carrito) {
        this.idOrden = idOrden;
        this.cliente = cliente;
        this.fechaOrden = fechaOrden;
        this.totalOrden = totalOrden;
        this.carrito = carrito;
    }

    public Integer getIdOrden() {
        return idOrden;
    }

    public void setIdOrden(Integer idOrden) {
        this.idOrden = idOrden;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Time getFechaOrden() {
        return fechaOrden;
    }

    public void setFechaOrden(Time fechaOrden) {
        this.fechaOrden = fechaOrden;
    }

    public Double getTotalOrden() {
        return totalOrden;
    }

    public void setTotalOrden(Double totalOrden) {
        this.totalOrden = totalOrden;
    }

    public Carrito getCarrito() {
        return carrito;
    }

    public void setCarrito(Carrito carrito) {
        this.carrito = carrito;
    }

    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("=============================================================================\n");
        sb.append("Numero De Orden: " + this.idOrden);
        sb.append("\n");
        sb.append("Fecha De Orden: " + this.fechaOrden);
        sb.append("\n");
        sb.append("Contrasena: " + this.cliente);
        sb.append("\n");
        sb.append("Contrasena: " + this.carrito);
        sb.append("\n");
        sb.append("Total De La Orden:" + this.totalOrden);
        sb.append("\n=============================================================================");
        return sb.toString();
    }
    //retorna el producto de la orden
    public static Producto getProductoOrden(String nombreProducto, List<Producto> lstProducto) {
        Producto productoCombo = null;
        for (Producto p : lstProducto) {
            if (nombreProducto.equals(p.getNombreProducto()) == true) {
                productoCombo = p;
            }
        }
        return productoCombo;
    }
    //retorna la orden deseada
    public static Orden getOrdenSeleccionada(DiarioFacil diarioFacil, int ordenSeleccionada) {
        Orden orden = null;
        if (ordenSeleccionada != 0) {
            for (Orden o : diarioFacil.getLstOrden()) {
                if (ordenSeleccionada == o.getIdOrden()) {
                    orden = o;
                }
            }

        } else {
            System.out.println("La Orden no existe.");
        }
        return orden;
    }

}
