package DiarioFacil.ulatina;

import java.sql.Time;
import java.util.List;

public class Admin extends Usuario {

    public Admin() {
    }

    public Admin(Integer id, String name, String password, Boolean login) {
        super(id, name, password, login);
    }

    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("=============================================================================\n");
        sb.append("Id: " + this.id);
        sb.append("\n");
        sb.append("Nombre: " + this.name);
        sb.append("\n");
        sb.append("Contrasena: *******");
        sb.append("\n");
        sb.append("Estado de conexion: " + this.login);
        sb.append("\n=============================================================================");
        return sb.toString();
    }

    public void Registrarse() {

    }
    //inicio de seccion como administrador
    public static Admin inicioSeccionAdministrador(DiarioFacil D, String nombre, String contrasena) {
        Admin usuario = new Admin();

        for (Admin c : D.getLstAdministradores()) {
            if (nombre.equals(c.name) && contrasena.equals(c.password)) {
                usuario = c;
            }
        }
        if (usuario.name.isEmpty() == true) {
            System.out.println("\n==================================================\nConexion Fallida:\nCredenciales Incorrectas\n==================================================\n");
        } else {
            System.out.println("\n==================================================\nBienvenido Administrador!\n==================================================\n");
            usuario.login = true;
        }

        return usuario;
    }
    //retorna el producto a agregar
    public static Producto agregarProducto(String id, String nombre, Double precio, Integer inventario, Integer stockMin, Categoria categoria) {
        Producto nuevoProducto = new Producto(id, nombre, precio, inventario, stockMin, categoria);

        return nuevoProducto;

    }
    //retorna el combo a agregar
    public static Combo agregarCombo(String idCombo, Double precioCombo, List<Producto> lstProducto) {
        Combo nuevoCombo = new Combo(idCombo, precioCombo, lstProducto);

        return nuevoCombo;

    }
    //retorna el proveedor a agregar
    public static Proveedor agregarProveedor(String idProveedor, String nombreProveedor, String correoProveedor, String direccionProveedor, String telefonoProveedor, List<Producto> lstProducto) {
        Proveedor nuevoProveedor = new Proveedor(idProveedor, nombreProveedor, correoProveedor, direccionProveedor, telefonoProveedor, lstProducto);

        return nuevoProveedor;

    }
    //retorna la Orden a agregar
    public static Orden agregarOrden(int idOrden, Cliente clienteOrden, Time fechaOrden, Carrito carritoOrden, Double totalOrden) {
        Orden nuevaOrden = new Orden(idOrden, clienteOrden, fechaOrden, totalOrden, carritoOrden);

        return nuevaOrden;

    }
    //retorna la promocion a agregar
    public static Promocion agregarPromocion(Producto productoPromocion, Double descuento) {
        Promocion nuevaPromo = new Promocion(productoPromocion, descuento);

        return nuevaPromo;
    }

}
