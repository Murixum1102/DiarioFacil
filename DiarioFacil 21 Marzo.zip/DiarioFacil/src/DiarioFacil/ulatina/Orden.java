/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DiarioFacil.ulatina;
import java.util.Calendar;
import java.util.List;

/**
 *
 * @author murip
 */
public class Orden {
    private Integer idOrden;
    private Calendar fechaOrden;
    private Integer totalOrden;
    private List<Producto> LstProductos;
}
