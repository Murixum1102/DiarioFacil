package DiarioFacil.ulatina;

import java.io.*;
import java.util.ArrayList;
import java.util.List;


public class Prueba {
    
 static BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
    static PrintStream out = System.out;
    
    public static void main(String[] args) throws IOException {
        DiarioFacil diarioFacil=new DiarioFacil();
        List<Cliente> listaClientes=new ArrayList<>();
    

        int opc;
        boolean noSalir = true;

        do{
            mostrarMenu();
            opc = leerOpcion();
            noSalir = ejecutarAccion(opc,diarioFacil,listaClientes);
            System.out.println(noSalir);
        }  while (noSalir=true);
    }

    public static void mostrarMenu() {

        out.println("\n===========================================================");
        out.println("1.  Iniciar Seccion.");
        out.println("2.  Registrarse en el Sistema.");
        out.println("3.  Salir.");
        out.println("===========================================================\n");
    }

    public static int leerOpcion() throws java.io.IOException {

        int opcion;

        out.print("Seleccione su opción:");
        opcion = Integer.parseInt(in.readLine());

        return opcion;
    }

    public static boolean ejecutarAccion(int opcion,DiarioFacil D,List<Cliente> lstCliente) throws java.io.IOException {
       
        boolean noSalir=true;
        int numProd = opcion;

        switch (numProd) {

            case 1: //Opcion Agregar Producto

                Admin.agregarProducto();
                break;

            case 2:// Registrarse
                
               lstCliente.add(Cliente.Registrarse());
               D.setLstCliente(lstCliente);
               System.out.println(D.getLstCliente());
                break;

            case 3:// Login 

                noSalir=false;
                
            break;

            default: //Cualquier otro valor dado por el usuario se considera inválido

                out.println("Opcion inválida");
                out.println();
                break;
        }
         return noSalir;
    }

    

    

    


    
    
}
