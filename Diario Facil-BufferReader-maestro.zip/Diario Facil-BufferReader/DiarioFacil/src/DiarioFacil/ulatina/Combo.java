package DiarioFacil.ulatina;

import java.util.List;

public class Combo {

    private String idCombo;
    private Double precioCombo;
    private List<Producto> LstProductosCombo;

    public Combo() {

    }

    public Combo(String idCombo, Double precioCombo, List<Producto> LstProductosCombo) {
        this.idCombo = idCombo;
        this.precioCombo = precioCombo;
        this.LstProductosCombo = LstProductosCombo;
    }

    public String getIdCombo() {
        return idCombo;
    }

    public void setIdCombo(String idCombo) {
        this.idCombo = idCombo;
    }

    public Double getPrecioCombo() {
        return precioCombo;
    }

    public void setPrecioCombo(Double precioCombo) {
        this.precioCombo = precioCombo;
    }

    public List<Producto> getLstProductosCombo() {
        return LstProductosCombo;
    }

    public void setLstProductosCombo(List<Producto> LstProductosCombo) {
        this.LstProductosCombo = LstProductosCombo;
    }

    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("=============================================================================\n");
        sb.append("Id.Combo: " + this.idCombo);
        sb.append("\n");
        sb.append("Precio De Combo: " + this.precioCombo);
        sb.append("\n");
        sb.append("Productos Del Combo: " + this.LstProductosCombo);
        sb.append("\n=============================================================================");
        return sb.toString();
    }
    //retorna el combo deseado
    public static Producto getProductoCombo(String nombreProducto, List<Producto> lstProducto) {
        Producto productoCombo = null;
        for (Producto p : lstProducto) {
            if (nombreProducto.equals(p.getNombreProducto()) == true) {
                productoCombo = p;
            }
        }
        return productoCombo;
    }
    //retorna el combo Del carrito
    public static Combo getComboCarrito(String idCombo, List<Combo> lstCombo) {
        Combo comboCarrito = null;
        for (Combo c : lstCombo) {
            if (idCombo.equals(c.idCombo) == true) {
                comboCarrito = c;
            }
        }
        return comboCarrito;
    }

}
