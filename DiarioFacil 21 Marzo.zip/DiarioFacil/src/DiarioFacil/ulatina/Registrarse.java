package DiarioFacil.ulatina;

public class Registrarse {

    public static void main(String[] args) {
        //(tipoCliente,cantidadDeCompras,id,Nombre,password,login)
        Cliente sanVito=new Cliente(Boolean.FALSE, Integer.MIN_VALUE, 154768390, "Vito", "1234", Boolean.FALSE);
 
        
        
        System.out.print("Ingrese su nombre de Usuario"+"\n");
        
    }

}
