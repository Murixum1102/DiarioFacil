package DiarioFacil.ulatina;

import java.util.List;

public class Promocion {

    private Producto productoPromocion;
    private Double descuento;

    public Promocion() {
    }

    public Promocion(Producto productoPromocion, Double descuento) {
        this.productoPromocion = productoPromocion;
        this.descuento = descuento;
    }

    public Producto getProductoPromocion() {
        return productoPromocion;
    }

    public void setProductoPromocion(Producto productoPromocion) {
        this.productoPromocion = productoPromocion;
    }

    public Double getDescuento() {
        return descuento;
    }

    public void setDescuento(Double descuento) {
        this.descuento = descuento;
    }

    @Override
    public String toString() {
        StringBuffer sb = new StringBuffer();
        sb.append("=============================================================================\n");
        sb.append("Producto En Promocion: " + this.productoPromocion);
        sb.append("\n");
        sb.append("Descuento: " + this.descuento);
        sb.append("\n=============================================================================");
        return sb.toString();
    }
    //retorna la promocion deseada
    public static Promocion getPromocionOrdenCarrito(String nombreProducto, List<Promocion> lstPromociones) {
        Promocion productoPromocion = null;
        for (Promocion p : lstPromociones) {
            if (nombreProducto.equals(p.productoPromocion.getNombreProducto()) == true) {
                productoPromocion = p;
            }
        }
        return productoPromocion;
    }

}
