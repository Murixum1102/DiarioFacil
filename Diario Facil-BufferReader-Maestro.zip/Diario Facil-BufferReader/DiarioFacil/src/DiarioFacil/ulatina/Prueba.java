package DiarioFacil.ulatina;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Prueba {

    static BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
    static PrintStream out = System.out;

    public static void main(String[] args) throws IOException {
        //Declaracion Administrador
        Admin administrador=new Admin(1, "diariofacil", "df", false);
        //Declaracion de Listas De DiarioFacil
        DiarioFacil diarioFacil = new DiarioFacil();
        List<Admin> listaAdministrador = new ArrayList<>();
        List<Cliente> listaClientes = new ArrayList<>();
        List<Orden> listaDeOrdenes = new ArrayList<>();
        List<Producto> listaProductos = new ArrayList<>();
        ArrayList<Categoria> listaCategorias=new ArrayList<>();
        //Insertar Admin a Lista De Amininistradores
        listaAdministrador.add(administrador);
        //Insertar Listas A Dirario Facil
        diarioFacil.setLstOrden(listaDeOrdenes);
        diarioFacil.setLstAdministradores(listaAdministrador);
        diarioFacil.setLstProductos(listaProductos);
        diarioFacil.setLstCategorias(listaCategorias);
        
        //Declaracion De Categorias
        Categoria bebidas = new Categoria("Bebidas", listaProductos);
        Categoria carnes = new Categoria("Carnes", listaProductos);
        Categoria harinas = new Categoria("Harinas", listaProductos);
        Categoria frutas = new Categoria("Frutas", listaProductos);
        Categoria verduras = new Categoria("Verduras", listaProductos);
        Categoria juguetes = new Categoria("juguetes", listaProductos);
        //Insertar Categorias A Lista De Categorias De DiarioFacil
        listaCategorias.add(bebidas);
        listaCategorias.add(carnes);
        listaCategorias.add(frutas);
        listaCategorias.add(verduras);
        listaCategorias.add(juguetes);
        //Declaracion Productos
        Producto coca = new Producto("01", "Coca Cola", 1.50d, 50, 5, bebidas);
        Producto agua = new Producto("02", "Agua", 1.25d, 60, 10, bebidas);
        //Insertar Productos A Lista De Productos
        listaProductos.add(coca);
        listaProductos.add(agua);
        
        //Variables para Correr Programa
        int opc;
        boolean noSalir = true;
        boolean conexion = true;
        //Inicio De Programa
        do {
            mostrarMenu();
            opc = leerOpcion();
            noSalir = ejecutarAccionMenuInicio(opc, diarioFacil, listaClientes, conexion,listaProductos,listaCategorias);

        } while (noSalir == true);
    }

    public static void mostrarMenu() {
        //Menu De Inicio General
        out.println("\n===========================================================");
        out.println("1.  Iniciar Seccion.");
        out.println("2.  Registrarse en el Sistema.");
        out.println("3.  Seccion administrativa(solo personal autorizado).");
        out.println("4.  Salir.");
        out.println("===========================================================\n");
    }

    public static void mostrarPaginaCliente(Cliente usuario) {
        //Pagina Unicamente Clientes
        out.println("\n===========================================================");
        //Ver Catalogo De Productos
        out.println("1.  Ver Catalogo.");
        //Ver Carrito De Cliente
        out.println("2.  Ver Carrito.");
        //Ver Todos Los Combos Disponibles
        out.println("3.  Ver Combos.");
        //VerHistorial De Ordenes
        out.println("4.  Ver Historial De Ordenes.");
        //Ver Productos Mas Comprados
        out.println("5.  Ver Productos Mas Comprados.");
        //Visible solo si el Cliente Es Premium y es para Ver Promociones
        if (usuario.getTipoCliente() == true) {
            out.println("6.  Ver Promociones.");
        }
        //Salir Del Menu Del Cliente
        out.println("7.  Salir.");
        out.println("===========================================================\n");
    }
    public static void mostrarPaginaAdministrador() {

        out.println("\n===========================================================");
        //Agregar Promocion
        out.println("1.  Agregar Promocion.");
        //Modificar Promocion
        out.println("2.  Modificar Promocion.");
        //Borrar Promocion
        out.println("3.  Borrar Promocion.");
        //Agregar Producto
        out.println("4.  Agregar Producto.");
        //Modificar Producto
        out.println("5.  Modificar Producto.");
        //Borrar Producto
        out.println("6.  Borrar Producto.");
        //Agregar Combo
        out.println("7.  Agregar Combo.");
        //Modificar Combo
        out.println("8.  Modificar Combo.");
        //Borrar Combo
        out.println("9.  Borrar Combo.");
        //Agregar Proveedor
        out.println("10. Agregar Proovedor.");
        //Modificar Proveedor
        out.println("11. Modificar Proovedor.");
        //Borrar Proveedor
        out.println("12. Borrar Proovedor.");
        //Salir Del Menu Administrador
        out.println("13. Salir.");
        out.println("===========================================================\n");
    }

    public static int leerOpcion() throws java.io.IOException {
    //lee la Opcion Ingresada Por El Usuario
        int opcion;
        out.println("\n===========================================================\n");

        out.print("Seleccione su opción:\n");
        opcion = Integer.parseInt(in.readLine());
        out.println("\n===========================================================\n");

        return opcion;
    }

    public static boolean ejecutarAccionMenuInicio(int opcion, DiarioFacil diarioFacil, List<Cliente> lstCliente, boolean conexion,List<Producto> lstProductos,List<Categoria> lstCategorias) throws java.io.IOException {
        int opc;
        boolean noSalir = true;
        int numProd = opcion;

        switch (numProd) {

            case 1: //Opcion Ingresar en el sistema como cliente
                Cliente usuario = new Cliente();
                out.print("\nIngrese su nombre de usuario\n");
                String nombre = in.readLine();
                out.print("Ingrese su contrasena\n");
                String contrasena = in.readLine();

                usuario = Cliente.inicioSeccion(diarioFacil, nombre, contrasena);
                if (usuario != null) {
                
                    conexion = true;
                    do {
                        mostrarPaginaCliente(usuario);
                        opc = leerOpcion();
                        ejecutarAccionPaginaCliente(opc,usuario,diarioFacil);
                    } while (conexion == true);
                }
                break;

            case 2:// Registrarse Como Cliente

                lstCliente.add(Cliente.Registrarse());
                diarioFacil.setLstCliente(lstCliente);
                break;

            case 3:// Entrar Al Sistema Como Administrador
                Admin administrador = new Admin();
                out.print("\nIngrese Nombre De Administrador\n");
                String nombreAdmin = in.readLine();
                out.print("Ingrese contraseña de administrador\n");
                String contrasenaAdmin= in.readLine();
                administrador = Admin.inicioSeccionAdministrador(diarioFacil, nombreAdmin, contrasenaAdmin);

                
                if (administrador.login == true) {
                    conexion = true;
                    do {
                        mostrarPaginaAdministrador();
                        opc = leerOpcion();
                        ejecutarAccionPaginaAdministrador(opc, diarioFacil,lstProductos,lstCategorias);
                    } while (conexion == true);
                }

                break;
                case 4://Salir del sistema por completo

                noSalir = false;

                break;

            default: //Cualquier otro valor dado por el usuario se considera inválido

                out.println("Opcion inválida");
                out.println();
                break;
        }
        return noSalir;
    }

    public static boolean ejecutarAccionPaginaCliente(int opcion,Cliente cliente,DiarioFacil diariofacil) throws java.io.IOException {

        boolean conexion = true;
        int numProd = opcion;

        switch (numProd) {

            case 1: //Opcion Ver catalogo

                break;

            case 2:// Opcion Ver carrito

                break;

            case 3:// Opcion Ver combos

                break;

            case 4:// Opcion Ver Historial De Compras
                  Cliente.getOrdenesCliente(diariofacil, cliente);
                break;

            case 5:// Opcion Ver Productos Mas Comprados

               

                break;
            case 6:// Opcion Ver Promociones(Solo Premium) 

                

                break;
            case 7:// Salir 

                conexion = false;
                cliente.setLogin(false);
                

                break;

            default: //Cualquier otro valor dado por el usuario se considera inválido

                out.println("Opcion inválida");
                out.println();
                break;
        }
        return conexion;
    }
    public static boolean ejecutarAccionPaginaAdministrador(int opcion, DiarioFacil diarioFacil,List<Producto> lstProductos,List<Categoria> lstCategorias) throws java.io.IOException {

        boolean conexion = true;
        int numProd = opcion;
        DiarioFacil df = new DiarioFacil();

        switch (numProd) {

            case 1: //Agregar Promocion
                
                
                
                  
                   

                break;

            case 2:// Modificar Promocion

                break;

            case 3:// Borrar Promocion

                break;

            case 4:// Agregar Producto
                Scanner scan = new Scanner(System.in);
                out.print("\n===========================================================\n");
                out.print("Ingresar un nuevo producto");
                out.println("\nIngrese el ID del producto");
                String id = in.readLine();
                out.println("Ingrese el nombre del producto");
                String nombre = in.readLine();
                out.println("Ingrese el precio del producto");
                Double precio = scan.nextDouble();
                out.println("Ingrese el inventario del producto");
                Integer inventario = scan.nextInt();
                out.println("Ingrese el Stock Mínimo del producto");
                Integer stock = scan.nextInt();
                for (Categoria c : diarioFacil.getLstCategorias()) {
                    out.print(c.getCategoria());
                }
                out.println("\nIngrese la Categoría Deseada.");
                String categoriaElegida = in.readLine();

                out.print("===========================================================\n");

                if (Categoria.getCategoriaSeleccionada(diarioFacil, categoriaElegida) != null) {
                    lstProductos.add(Admin.agregarProducto(id, nombre, precio, inventario, stock, Categoria.getCategoriaSeleccionada(diarioFacil, categoriaElegida)));
                    
                    out.print("Producto Agregado Con Exito.");
                } else {
                    out.print("Error, Por Favor Intentelo De Nuevo.");
                }
                break;

            case 5:// Modificar Producto 

                

                break;
            
            case 6: //Borrar Producto
                
                break;
           
            case 7: // Agregar Combo
                        
                break;
                
            case 8: //Modificar Combo
                
                break;
                
            case 9: //Borrar Combo
                    
                break;
                
            case 10: //Agregar Proovedor
                
                break;
                
            case 11: //Modificar Proovedor
                
                break;
                
            case 12: //Borrar Proovedor
                
                break;
                
            case 13: //Salir
                    conexion = false;
                break;
                  

            default: //Cualquier otro valor dado por el usuario se considera inválido

                out.println("Opcion inválida");
                out.println();
                break;
        }
        return conexion;
    }

}


