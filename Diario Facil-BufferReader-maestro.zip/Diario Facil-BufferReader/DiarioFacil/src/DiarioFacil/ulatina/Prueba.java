package DiarioFacil.ulatina;

import com.sun.javafx.scene.control.skin.VirtualFlow;
import java.io.*;
import java.sql.Time;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Scanner;

public class Prueba {

    static BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
    static PrintStream out = System.out;

    public static void main(String[] args) throws IOException {
        //Declaracion Administrador
        Admin administrador = new Admin(1, "diariofacil", "df", false);
        //Declaracion De DiarioFacil
        DiarioFacil diarioFacil = new DiarioFacil();
        //Declaracion De Listas De DiarioFacil 
        List<Admin> listaAdministrador = new ArrayList<>();
        List<Cliente> listaClientes = new ArrayList<>();
        List<Orden> listaDeOrdenes = new ArrayList<>();
        List<Producto> listaProductos = new ArrayList<>();
        List<Categoria> listaCategorias = new ArrayList<>();
        List<Combo> listaDeCombos=new ArrayList<>();
        List<Proveedor> listaProveedores=new ArrayList<>();
        List<Carrito> listaDeCarrito=new ArrayList<>();
        List<Promocion> listaDePromociones=new ArrayList<>();
        List<ProductoConsumido> listaDeProductosConsumidos=new ArrayList<>();
        
        //Insertar Admin a Lista De Amininistradores
        listaAdministrador.add(administrador);
        //Insertar Listas A Dirario Facil
        diarioFacil.setLstOrden(listaDeOrdenes);
        diarioFacil.setLstAdministradores(listaAdministrador);
        diarioFacil.setLstProductos(listaProductos);
        diarioFacil.setLstCategorias(listaCategorias);
        diarioFacil.setLstProductosConsumidos(listaDeProductosConsumidos);
        diarioFacil.setLstPromociones(listaDePromociones);
        diarioFacil.setLstProveedor(listaProveedores);
        diarioFacil.setLstCliente(listaClientes);
        diarioFacil.setLstCombos(listaDeCombos);

        //Declaracion De Categorias
        Categoria bebidas = new Categoria("Bebidas", listaProductos);
        Categoria carnes = new Categoria("Carnes", listaProductos);
        Categoria harinas = new Categoria("Harinas", listaProductos);
        Categoria frutas = new Categoria("Frutas", listaProductos);
        Categoria verduras = new Categoria("Verduras", listaProductos);
        Categoria juguetes = new Categoria("juguetes", listaProductos);
        
        //Declaracion Productos 
        Producto fresa=new Producto("12", "Fresa", 1000.0, 100, 10, frutas);
        Producto chorizo=new Producto("17", "Chorizo", 2400.50, 25, 5, carnes);
        Producto carrito=new Producto("62", "Carrito", 5000.25, 50, 10, juguetes);
        Producto papa=new Producto("80", "papa", 750.0, 40, 15, verduras);
        Producto pan=new Producto("431", "Pan", 3200.0, 25, 5, harinas);
        Producto galleta=new Producto("653", "Galleta", 1250.75, 75, 10, harinas);
        
        //Declaracion Productos Consumidos
        ProductoConsumido productoConsumidoFresa=new ProductoConsumido(fresa,6);
        ProductoConsumido productoConsumidochorizo=new ProductoConsumido(chorizo,15);
        ProductoConsumido productoConsumidocarrito=new ProductoConsumido(carrito,76);
        ProductoConsumido productoConsumidopapa=new ProductoConsumido(papa,14);
        ProductoConsumido productoConsumidopan=new ProductoConsumido(pan,9);
        ProductoConsumido productoConsumidogalleta=new ProductoConsumido(galleta,98);
        
        //Insertar Productos A Lista De Productos De DiarioFacil
        listaProductos.add(fresa);
        listaProductos.add(chorizo);
        listaProductos.add(carrito);
        listaProductos.add(papa);
        listaProductos.add(pan);
        listaProductos.add(galleta);
        
        //Insertar Categorias A Lista De Categorias De DiarioFacil
        listaCategorias.add(bebidas);
        listaCategorias.add(carnes);
        listaCategorias.add(frutas);
        listaCategorias.add(verduras);
        listaCategorias.add(juguetes);

        //Variables para Correr Programa
        int opc;
        boolean noSalir = true;
        boolean conexion = true;
        //Inicio De Programa
        do {
            mostrarMenu();
            opc = leerOpcion();
            noSalir = ejecutarAccionMenuInicio(opc, diarioFacil, listaClientes, conexion, listaProductos, listaCategorias,listaDeCombos,listaProveedores,listaDeCarrito,listaDeOrdenes,listaDePromociones,listaDeProductosConsumidos);

        } while (noSalir == true);
    }

    public static void mostrarMenu() {
        //Menu De Inicio General
        out.println("\n===========================================================");
        out.println("1.  Iniciar Seccion.");
        out.println("2.  Registrarse en el Sistema.");
        out.println("3.  Seccion administrativa(solo personal autorizado).");
        out.println("4.  Salir.");
        out.println("===========================================================\n");
    }
    public static void mostrarMenuAgregarProductoOrden() {
        //Pagina De Agregar Producto De Orden
        out.println("\n===========================================================");
        //Agregar Un Nuevo Producto a Carrito
        out.println("1.  Agregar Producto A Orden.");
        //Salir Del Agregado Del Producto En El Carrito de La Orden
        out.println("2.  No Anadir Mas Producto.");
        out.println("===========================================================\n");
    }
    public static void mostrarMenuAgregarPromocionAOrden() {
        //Pagina De Agregar Promocion A Orden
        out.println("\n===========================================================");
        //Agregar Una Nueva Promocion Al Carrito De La Orden
        out.println("1.  Agregar Promocion a Orden.");
        //Salir Del Agregado De la Promocion Del Carrito De La Orden
        out.println("2.  No Anadir Mas Promociones.");
        out.println("===========================================================\n");
    }
    public static void mostrarMenuAgregarComboAOrden() {
        //Pagina De Agregar Combos Al Carrito De Ordenes
        out.println("\n===========================================================");
        //Agregar Un Nuevo Combo Al Carrito De La Orden
        out.println("1.  Agregar Combo a Orden.");
        //Salir Del Agregado Del Combo Del Carrito De La Orden
        out.println("2.  No Anadir Mas Combos.");
        out.println("===========================================================\n");
    }
    public static void mostrarMenuAgregarProductoProveedores() {
        //Pagina De Agregar Producto De Combo
        out.println("\n===========================================================");
        //Agregar Un Nuevo Combo
        out.println("1.  Agregar Producto A Proveedor.");
        //Salir Del Agregado Del Producto En El Combo
        out.println("2.  No Anadir Mas Producto.");
        out.println("===========================================================\n");
    }
    public static void mostrarMenuAgregarProductoCombo() {
        //Pagina De Agregar Producto De Combo
        out.println("\n===========================================================");
        //Agregar Un Nuevo Combo
        out.println("1.  Agregar Producto A Combo.");
        //Salir Del Agregado Del Producto En El Combo
        out.println("2.  No Anadir Mas Producto.");
        out.println("===========================================================\n");
    }
    public static void mostrarMenuAgregarProductoCliente() {
        //Pagina De Agregar Producto A Cliente
        out.println("\n===========================================================");
        //Agregar Un Producto
        out.println("1.  Agregar Producto A Su Carrito.");
        //Salir Del Agregado Del Producto 
        out.println("2.  No Anadir Mas Producto.");
        out.println("===========================================================\n");
    }
        public static void mostrarMenuAgregarComboCliente() {
        //Pagina De Agregar Combo A Cliente
        out.println("\n===========================================================");
        //Agregar Un Combo
        out.println("1.  Agregar Combo A Su Carrito.");
        //Salir Del Agregado Del Combo
        out.println("2.  No Anadir Mas Combos.");
        out.println("===========================================================\n");
    }
            public static void mostrarMenuAgregarPromocionCliente() {
        //Pagina De Agregar Promocion A Cliente
        out.println("\n===========================================================");
        //Agregar Una Promocion
        out.println("1.  Agregar Promocion A Su Carrito.");
        //Salir Del Agregado Del Combo
        out.println("2.  No Anadir Mas Promociones.");
        out.println("===========================================================\n");
    }


    public static void mostrarPaginaCliente(Cliente usuario) {
        //Pagina Unicamente Clientes
        out.println("\n===========================================================");
        //Ver Catalogo De Productos
        out.println("1.  Ver Catalogo.");
        //Ver Carrito De Cliente
        out.println("2.  Ver Carrito.");
        //Ver Todos Los Combos Disponibles
        out.println("3.  Ver Combos.");
        //VerHistorial De Ordenes
        out.println("4.  Ver Historial De Ordenes.");
        //Ver Productos Mas Comprados
        out.println("5.  Ver Productos Mas Comprados.");
        //Visible solo si el Cliente Es Premium y es para Ver Promociones
        if (usuario.getTipoCliente() == true) {
            out.println("6.  Ver Promociones.");
        }
        //Salir Del Menu Del Cliente
        out.println("7.  Salir.");
        out.println("===========================================================\n");
    }

    public static void mostrarPaginaAdministrador() {

        out.println("\n===========================================================");
        //Agregar Promocion
        out.println("1.  Agregar Promocion.");
        //Modificar Promocion
        out.println("2.  Modificar Promocion.");
        //Borrar Promocion
        out.println("3.  Borrar Promocion.");
        //Agregar Producto
        out.println("4.  Agregar Producto.");
        //Modificar Producto
        out.println("5.  Modificar Producto.");
        //Borrar Producto
        out.println("6.  Borrar Producto.");
        //Agregar Combo
        out.println("7.  Agregar Combo.");
        //Modificar Combo
        out.println("8.  Modificar Combo.");
        //Borrar Combo
        out.println("9.  Borrar Combo.");
        //Agregar Proveedor
        out.println("10. Agregar Proovedor.");
        //Modificar Proveedor
        out.println("11. Modificar Proovedor.");
        //Borrar Proveedor
        out.println("12. Borrar Proovedor.");
        //Crear Orden
        out.println("13.  Crear Orden.");
        //Modificar Orden
        out.println("14.  Modificar Orden.");
        //Borrar Orden
        out.println("15.  Borrar Orden.");
        //Ver Ordenes
        out.println("16.  Ver Ordenes.");
        //Salir Del Menu Administrador
        out.println("17. Salir.");
        out.println("===========================================================\n");
    }

    public static int leerOpcion() throws java.io.IOException {
        //lee la Opcion Ingresada Por El Usuario
        int opcion;
        out.println("\n===========================================================\n");

        out.print("Seleccione su opción:\n");
        opcion = Integer.parseInt(in.readLine());
        out.println("\n===========================================================\n");

        return opcion;
    }

    public static boolean ejecutarAccionMenuInicio(int opcion, DiarioFacil diarioFacil, List<Cliente> lstCliente, boolean conexion, List<Producto> lstProductos, List<Categoria> lstCategorias,List<Combo> lstCombos,List<Proveedor> lstProveedores,List<Carrito> lstCarritos,List<Orden> lstOrdenes,List<Promocion> lstPromociones,List<ProductoConsumido> lstProductosConsumidos) throws java.io.IOException {
        Scanner sc=new Scanner(System.in);
        int opc;
        boolean noSalir = true;
        int numProd = opcion;

        switch (numProd) {

            case 1: //Opcion Ingresar en el sistema como cliente
                Cliente usuario = new Cliente();
                out.print("\nIngrese su nombre de usuario\n");
                String nombre = sc.next();
                out.print("Ingrese su contrasena\n");
                String contrasena =sc.next();

                usuario = Cliente.inicioSeccion(diarioFacil, nombre, contrasena);
                if (usuario != null) {

                    conexion = true;
                    do {
                        mostrarPaginaCliente(usuario);
                        opc = leerOpcion();
                        ejecutarAccionPaginaCliente(opc, usuario, diarioFacil,lstProductos,lstCarritos,lstCombos,lstPromociones,lstProductosConsumidos);
                    } while (conexion == true);
                }
                break;

            case 2:// Registrarse Como Cliente

                lstCliente.add(Cliente.Registrarse());
                diarioFacil.setLstCliente(lstCliente);
                break;

            case 3:// Entrar Al Sistema Como Administrador
                Admin administrador = new Admin();
                out.print("\nIngrese Nombre De Administrador\n");
                String nombreAdmin = sc.next();
                out.print("Ingrese contraseña de administrador\n");
                String contrasenaAdmin = sc.next();
                administrador = Admin.inicioSeccionAdministrador(diarioFacil, nombreAdmin, contrasenaAdmin);

                if (administrador.login == true) {
                    conexion = true;
                    do {
                        mostrarPaginaAdministrador();
                        opc = leerOpcion();
                        conexion=ejecutarAccionPaginaAdministrador(opc, diarioFacil, lstProductos, lstCategorias,lstCombos,lstProveedores,lstCarritos,lstCliente,lstOrdenes,lstPromociones);
                    } while (conexion == true);
                }

                break;
            case 4://Salir del sistema por completo

                noSalir = false;

                break;

            default: //Cualquier otro valor dado por el usuario se considera inválido

                out.println("Opcion inválida");
                out.println();
                break;
        }
        return noSalir;
    }
    

    public static boolean ejecutarAccionPaginaCliente(int opcion, Cliente cliente, DiarioFacil diariofacil,List<Producto> lstProductos,List<Carrito> lstCarritos,List<Combo> lstTodosLosCombos,List<Promocion> lstTodaslasPromociones,List<ProductoConsumido> lstTodosLosProductosConsumidos) throws java.io.IOException {

        boolean conexion = true;
        int numProd = opcion;
        List<Producto> lstProductosCarritoCliente=new ArrayList<>();
        List<Promocion> lstPromocionesCarritoCliente=new ArrayList<>();
        List<Combo> lstComboCarritoCliente=new ArrayList<>();
        Carrito carritoCliente=new Carrito(cliente,lstProductosCarritoCliente,lstPromocionesCarritoCliente,lstComboCarritoCliente);

        switch (numProd) {
            
            case 1: //Opcion Ver catalogo Productos
                boolean agregarProductoCliente=true;
                for (Producto p : lstProductos) {
                    out.print("\n"+p.getNombreProducto());
                }
                mostrarMenuAgregarProductoCliente();
                do{
                    agregarProductoCliente=ejecutarAccionAgregarProductoCliente(leerOpcion(), lstProductos, lstProductosCarritoCliente);
                }while(agregarProductoCliente==true);
                break;

            case 2:// Opcion Ver carrito
                System.out.println(Cliente.getCarritoCliente(lstCarritos, cliente));
                break;

            case 3:// Opcion Ver combos
            boolean agregarComboCliente=true;
                for (Combo c : lstTodosLosCombos) {
                    out.print("\n"+c.getIdCombo()+c.getLstProductosCombo());
                }
                mostrarMenuAgregarComboCliente();
                do{
                    agregarComboCliente=ejecutarAccionAgregarComboCliente(leerOpcion(), lstTodosLosCombos, lstComboCarritoCliente);
                }while(agregarComboCliente==true);
                break;

            case 4:// Opcion Ver Historial De Compras
                Cliente.getOrdenesCliente(diariofacil, cliente);
                break;

            case 5:// Opcion Ver Productos Mas Comprados
                int auxCounter=0;
            
               // Collections.sort(lstTodosLosProductosConsumidos.iterator());
                
                break;
            case 6:// Opcion Ver Promociones(Solo Premium) 
                if(cliente.getTipoCliente()==true){
                    boolean agregarPromocionCliente=true;
                for (Promocion p : lstTodaslasPromociones) {
                    out.print("\n"+p.getProductoPromocion().getNombreProducto());
                }
                mostrarMenuAgregarPromocionCliente();
                do{
                    agregarPromocionCliente=ejecutarAccionAgregarPromocionCliente(leerOpcion(), lstPromocionesCarritoCliente, lstTodaslasPromociones);
                }while(agregarPromocionCliente==true);
                break;
                }
                break;
            case 7:// Salir 

                conexion = false;
                cliente.setLogin(false);

                break;

            default: //Cualquier otro valor dado por el usuario se considera inválido

                out.println("Opcion inválida");
                out.println();
                break;
        }
        return conexion;
    }
    public static boolean ejecutarAccionAgregarComboCliente(int opcion,List<Combo> lstTodosLosCombos,List<Combo> lstComboCliente) throws java.io.IOException {
        Scanner sc=new Scanner(System.in);
        int opc;
        boolean ingresoProducto = true;
        int numProd = opcion;

        switch (numProd) {

            case 1: //Opcion Ingresar en el sistema como cliente
                out.print("Ingrese el Nombre Del Producto Que Desea Agregar.");
                String nombreComboSeleccionado=sc.next();
                lstComboCliente.add(Cliente.getComboCliente(nombreComboSeleccionado,lstTodosLosCombos));
                break;
            case 2://Salir del Agregado Del Producto A Combos

                ingresoProducto = false;

                break;

            default: //Cualquier otro valor dado por el Administrador se considera inválido

                out.println("Opcion inválida");
                out.println();
                break;
        }
        return ingresoProducto;
    }
    public static boolean ejecutarAccionAgregarPromocionCliente(int opcion,List<Promocion> lstTodasLasPromociones,List<Promocion> lstPromocionesCarritoCliente) throws java.io.IOException {
        Scanner sc=new Scanner(System.in);
        int opc;
        boolean ingresoProducto = true;
        int numProd = opcion;

        switch (numProd) {

            case 1: //Opcion Ingresar en el sistema como cliente
                out.print("Ingrese el Nombre De La Promocion Que Desea Agregar.");
                String nombrePromocionSeleccionado=sc.next();
                lstPromocionesCarritoCliente.add(Cliente.getPromocionCliente(nombrePromocionSeleccionado,lstTodasLasPromociones));
                break;
            case 2://Salir del Agregado Del Producto A Combos

                ingresoProducto = false;

                break;

            default: //Cualquier otro valor dado por el Administrador se considera inválido

                out.println("Opcion inválida");
                out.println();
                break;
        }
        return ingresoProducto;
    }
    public static boolean ejecutarAccionAgregarProductoCliente(int opcion,List<Producto> lstTodosLosProductos,List<Producto> lstProductoDeCliente) throws java.io.IOException {
        Scanner sc=new Scanner(System.in);
        int opc;
        boolean ingresoProducto = true;
        int numProd = opcion;

        switch (numProd) {

            case 1: //Opcion Ingresar en el sistema como cliente
                out.print("Ingrese el Nombre Del Producto Que Desea Agregar.");
                String nombreProductoSeleccionado=sc.next();
                lstProductoDeCliente.add(Cliente.getProductoCliente(nombreProductoSeleccionado,lstTodosLosProductos));
                break;
            case 2://Salir del Agregado Del Producto A Combos

                ingresoProducto = false;

                break;

            default: //Cualquier otro valor dado por el Administrador se considera inválido

                out.println("Opcion inválida");
                out.println();
                break;
        }
        return ingresoProducto;
    }

    public static boolean ejecutarAccionPaginaAdministrador(int opcion, DiarioFacil diarioFacil, List<Producto> lstProductos, List<Categoria> lstCategorias,List<Combo> lstCombos,List<Proveedor> lstProveedores,List<Carrito> lstCarritos,List<Cliente> lstClientes,List<Orden> lstOrdenes,List<Promocion> lstPromociones) throws java.io.IOException {
        Scanner scan = new Scanner(System.in);
        boolean conexion = true;
        int numProd = opcion;
        DiarioFacil df = new DiarioFacil();

        switch (numProd) {

            case 1: //Agregar Promocion
            out.print("\n===========================================================\n");
                out.print("Ingrese el descuento de la Promoción\n");
                Double precioPromo = scan.nextDouble();
                out.print("\n===========================================================\n"); 
                out.print("Estos son los productos existentes");
                for (Producto p : diarioFacil.getLstProductos()){
                    out.print("\n" + p.getNombreProducto());
                }
                out.print("\n===========================================================\n");                
                out.print("\nSeleccione el Producto en promoción\n");
                String productoExistente = in.readLine();
                out.print("\n===========================================================\n");
                
                if (Producto.getProductoSeleccionado(diarioFacil, productoExistente)!= null){
                    lstPromociones.add(Admin.agregarPromocion(Producto.getProductoSeleccionado(diarioFacil, productoExistente), precioPromo));
                    out.println("\n¡Combo creado con éxito!");
                }else{
                    out.println("Por favor intente de nuevo");
                }  
                break;

            case 2:// Modificar Promocion
                out.print("\n===========================================================\n");
                out.print("Estos son las promociones existentes y sus precios con descuento:");
                for(Promocion p : diarioFacil.getLstPromociones()){
                    out.print("\n" + p.getProductoPromocion().getNombreProducto() + " " + p.getProductoPromocion().getPrecioProducto()*p.getDescuento());
                }
                out.print("\n===========================================================\n");                
                out.print("\nSeleccione la promoción a modificar\n");
                String promoExistente = in.readLine();
                out.print("\n===========================================================\n");
                out.println("\nIngrese el nuevo descuento de la Promoción:");
                Double nuevoDescuento = scan.nextDouble();
                if (Promocion.getPromocionOrdenCarrito(promoExistente, lstPromociones) != null){
                    Promocion.getPromocionOrdenCarrito(promoExistente, lstPromociones).setDescuento(nuevoDescuento);
                    out.println("\n¡Promoción modificada con éxito!");
                }

                break;

            case 3:// Borrar Promocion
            
                break;

            case 4:// Agregar Producto
                out.print("\n===========================================================\n");
                out.print("Ingresar un nuevo producto");
                out.println("\nIngrese el ID del producto");
                String id = scan.next();
                out.println("Ingrese el nombre del producto");
                String nombre = scan.next();
                out.println("Ingrese el precio del producto");
                Double precio = scan.nextDouble();
                out.println("Ingrese el inventario del producto");
                Integer inventario = scan.nextInt();
                out.println("Ingrese el Stock Mínimo del producto");
                Integer stock = scan.nextInt();
                for (Categoria c : diarioFacil.getLstCategorias()) {
                    out.print("\n"+c.getCategoria());
                }
                out.println("\nIngrese la Categoría Deseada.");
                String categoriaElegida = in.readLine();

                out.print("===========================================================\n");

                if (Categoria.getCategoriaSeleccionada(diarioFacil, categoriaElegida) != null) {
                    lstProductos.add(Admin.agregarProducto(id, nombre, precio, inventario, stock, Categoria.getCategoriaSeleccionada(diarioFacil, categoriaElegida)));

                    out.print("Producto Agregado Con Exito.");
                } else {
                    out.print("Error, Por Favor Intentelo De Nuevo.");
                }
                break;

            case 5:// Modificar Producto 
                
                out.print("\n===========================================================\n");
                out.print("Estos son los Productos Existentes:");
                for(Producto p : diarioFacil.getLstProductos()){
                    out.print("\n" + p.getNombreProducto());
                }
                out.print("\n===========================================================\n");                
                out.print("\nSeleccione El Producto a Modificar\n");
                String productoExistenteAModificar = in.readLine();
                out.print("\n===========================================================\n");
                out.println("\nIngrese el nuevo Precio Del Producto:");
                Double nuevoPrecio = scan.nextDouble();
                out.println("\nIngrese el nuevo Inventario Del Producto:");
                int nuevoInventarioProducto = scan.nextInt();
                out.println("\nIngrese el nuevo Inventario Minimo Del Producto:");
                int nuevoInventarioMinimoProducto = scan.nextInt();
                
                if (Producto.getProductoSeleccionado(diarioFacil, productoExistenteAModificar) != null){
                    Producto.getProductoSeleccionado(diarioFacil, productoExistenteAModificar).setPrecioProducto(nuevoPrecio);
                    Producto.getProductoSeleccionado(diarioFacil, productoExistenteAModificar).setInventarioActual(nuevoInventarioProducto);
                    Producto.getProductoSeleccionado(diarioFacil, productoExistenteAModificar).setStockMinimo(nuevoInventarioMinimoProducto);
                    
                    out.println("\n¡Producto modificado con éxito!");
                }

                break;

            case 6: //Borrar Producto

                break;

            case 7: // Agregar Combo
                boolean ingresoProducto=true;
                List<Producto> lstProductoCombo=new ArrayList();
                
                out.print("\n===========================================================\n");
                out.print("Ingresar un nuevo Combo:\n");
                out.println("\nIngrese el ID del Combo:\n");
                String idCombo = scan.next();
                for (Producto p : lstProductos) {
                    System.out.println("\n"+p.getNombreProducto());
                }
                do{
                    mostrarMenuAgregarProductoCombo();
                   ingresoProducto=ejecutarAccionAgregarProductoCombo(leerOpcion(),lstProductos,lstProductoCombo);
                }while(ingresoProducto==true);
                
                out.println("Ingrese el precio del Combo:\n");
                Double precioCombo = scan.nextDouble();

                out.print("===========================================================\n");
                lstCombos.add(Admin.agregarCombo(idCombo, precioCombo, lstProductoCombo));
                break;

            case 8: //Modificar Combo
                out.print("\n===========================================================\n");
                out.print("Estos son los Combos existentes y sus precios:");
                for(Combo c : diarioFacil.getLstCombos()){
                    out.print("\n" + c.getIdCombo() + " " +"\n===========================================================\n"+ c.getLstProductosCombo()+"\"\\n===========================================================\nPrecio:"+c.getPrecioCombo());
                }
                out.print("\n===========================================================\n");                
                out.print("\nSeleccione el Combo a modificar\n");
                String ComboExistente = in.readLine();
                out.print("\n===========================================================\n");
                out.println("\nIngrese el nuevo descuento de la Promoción:");
                Double nuevoPrecioCombo = scan.nextDouble();
                if (Combo.getComboCarrito(ComboExistente, lstCombos) != null){
                    Combo.getComboCarrito(ComboExistente, lstCombos).setPrecioCombo(nuevoPrecioCombo);
                    out.println("\n¡Combo modificado con éxito!");
                }
                break;

            case 9: //Borrar Combo

                break;

            case 10: //Agregar Proovedor
                boolean ingresoProductoProveedor=true;
                List<Producto> lstProductoProveedor=new ArrayList();
                
                out.print("\n===========================================================\n");
                out.print("Ingresar un nuevo Proveedor.\n");
                out.println("\nIngrese el ID Del Proveedor:\n");
                String idProveedor = scan.next();
                out.println("\nIngrese el Nombre Del Proveedor:\n");
                String nombreProveedor = scan.next();
                out.println("\nIngrese el Correo Del Proveedor:\n");
                String correoProveedor = scan.next();
                out.println("\nIngrese el Telefono Del Proveedor:\n");
                String telefonoProveedor = scan.next();
                out.println("\nIngrese La Direccion Del Proveedor:\n");
                String direccionProveedor = scan.next();
                for (Producto p : lstProductos) {
                    System.out.println("\n"+p.getNombreProducto());
                }
                do{
                    mostrarMenuAgregarProductoProveedores();
                   ingresoProducto=ejecutarAccionAgregarProductoProveedor(leerOpcion(),lstProductos,lstProductoProveedor);
                }while(ingresoProducto==true);

                out.print("===========================================================\n");
                lstProveedores.add(Admin.agregarProveedor(idProveedor, nombreProveedor, correoProveedor, direccionProveedor, telefonoProveedor, lstProductoProveedor));

                break;

            case 11: //Modificar Proovedor

                break;

            case 12: //Borrar Proovedor

                break;
            case 13: //Crear Orden
                
                boolean ingresoProductoOrden=true;
                boolean ingresoPromocionOrden=true;
                boolean ingresoComboOrden=true;
                Cliente clienteOrden=null;
                Carrito carritoOrden=new Carrito();
                List<Producto> lstProductoOrdenCarrito=new ArrayList<>();
                List<Promocion> lstPromocionOrdenCarrito=new ArrayList<>();
                List<Combo> lstComboOrdenCarrito=new ArrayList<>();
                carritoOrden.setLstProductosCarrito(lstProductoOrdenCarrito);
                carritoOrden.setLstPromocionesCarrito(lstPromocionOrdenCarrito);
                carritoOrden.setLstCombosCarrito(lstComboOrdenCarrito);
                out.print("\n===========================================================\n");
                out.print("Ingresar una Nueva Orden.\n");
                out.println("\nIngrese el ID De La Orden:\n");
                int idOrden = scan.nextInt();
                out.println("\nIngrese el Nombre Del Cliente:\n");
                String nombreClienteOrden = scan.next();
                for(Cliente c:lstClientes){
                    if(nombreClienteOrden.equals(c.name)==true){
                        clienteOrden=c;
                    }
                }
                carritoOrden.setCarritoCliente(clienteOrden);
                Time fechaCreacionDeOrden=Time.valueOf(LocalTime.MIN);
                out.print("===========================================================\n");
                out.print("Productos A Agregar:\n");
                for (Producto p : lstProductos) {
                    out.println(p.getNombreProducto());
                }
                out.print("===========================================================\n");
                do{
                    mostrarMenuAgregarProductoOrden();
                   ingresoProductoOrden=ejecutarAccionAgregarProductoOrdenCarrito(leerOpcion(),lstProductos,lstProductoOrdenCarrito);
                }while(ingresoProductoOrden==true);
                out.print("===========================================================\n");
                out.print("\nProductos En Promocion A Agregar:");
                for (Promocion p : lstPromociones) {
                    out.print("\n"+p.getProductoPromocion().getNombreProducto());
                }
                out.print("===========================================================\n");
                do{
                    mostrarMenuAgregarPromocionAOrden();
                   ingresoPromocionOrden=ejecutarAccionAgregarPromocionOrdenCarrito(leerOpcion(), lstPromociones, lstPromocionOrdenCarrito);
                }while(ingresoPromocionOrden==true);
                out.print("===========================================================\n");
                out.print("\nCombos A Agregar:");
                for (Combo c : lstCombos) {
                    out.print("\n"+c.getIdCombo()+"\n"+c.getLstProductosCombo());
                }
                out.print("===========================================================\n");
                do{
                    mostrarMenuAgregarComboAOrden();
                   ingresoComboOrden=ejecutarAccionAgregarComboOrdenCarrito(leerOpcion(),lstCombos,lstComboOrdenCarrito);
                }while(ingresoComboOrden==true);
                System.out.println("Ingrese El Total De La Orden:\n");
                int totalOrden=scan.nextInt();
                Orden nuevaOrden=new Orden(idOrden, clienteOrden, fechaCreacionDeOrden, totalOrden, carritoOrden);
                lstOrdenes.add(nuevaOrden);

                out.print("===========================================================\n");

                break;
            case 14: //Modificar Orden

                break;
            case 15: //Borrar Orden

                break;
            case 16: //Ver Ordenes
                for (Orden o : lstOrdenes) {
                    out.print(o);
                }

                break;
            case 17: //Salir
                conexion = false;
                break;

            default: //Cualquier otro valor dado por el usuario se considera inválido

                out.println("Opcion inválida");
                out.println();
                break;
        }
        return conexion;
    }
     public static boolean ejecutarAccionAgregarProductoCombo(int opcion,List<Producto> lstTodosLosProductos,List<Producto> lstProductoDeCombo) throws java.io.IOException {
        int opc;
        boolean ingresoProducto = true;
        int numProd = opcion;

        switch (numProd) {

            case 1: //Opcion Ingresar en el sistema como cliente
                out.print("Ingrese el Nombre Del Producto Que Desea Agregar.");
                String nombreProductoSeleccionado=in.readLine();
                for (Producto p : lstTodosLosProductos) {
                    if(nombreProductoSeleccionado.equals(p.getNombreProducto())==true){
                        lstProductoDeCombo.add(Combo.getProductoCombo(nombreProductoSeleccionado, lstProductoDeCombo));
                    }
                }
                break;
            case 2://Salir del Agregado Del Producto A Combos

                ingresoProducto = false;

                break;

            default: //Cualquier otro valor dado por el Administrador se considera inválido

                out.println("Opcion inválida");
                out.println();
                break;
        }
        return ingresoProducto;
    }
     public static boolean ejecutarAccionAgregarProductoProveedor(int opcion,List<Producto> lstTodosLosProductos,List<Producto> lstProductoDeProveedor) throws java.io.IOException {
        Scanner sc=new Scanner(System.in);
         int opc;
        boolean ingresoProducto = true;
        int numProd = opcion;

        switch (numProd) {

            case 1: //Opcion Ingresar en el sistema como cliente
                out.print("Ingrese el Nombre Del Producto Que Desea Agregar.");
                String nombreProductoSeleccionado=sc.next();
                for (Producto p : lstTodosLosProductos) {
                    if(nombreProductoSeleccionado.equals(p.getNombreProducto())==true){
                        lstProductoDeProveedor.add(Proveedor.getProductoProveedor(nombreProductoSeleccionado, lstProductoDeProveedor));
                    }
                }
                break;
            case 2://Salir del Agregado Del Producto A Combos

                ingresoProducto = false;

                break;

            default: //Cualquier otro valor dado por el Administrador se considera inválido

                out.println("Opcion inválida");
                out.println();
                break;
        }
        return ingresoProducto;
    }
     public static boolean ejecutarAccionAgregarProductoOrdenCarrito(int opcion,List<Producto> lstTodosLosProductos,List<Producto> lstProductoDeOrdenCarrito) throws java.io.IOException {
        Scanner sc=new Scanner(System.in);
        int opc;
        boolean ingresoProductoOrdenCarrito = true;
        int numProd = opcion;

        switch (numProd) {

            case 1: //Opcion Ingresar en el sistema como cliente
                out.print("Ingrese el Nombre Del Producto Que Desea Agregar.\n");
                String nombreProductoSeleccionado=sc.next();
                for (Producto p : lstTodosLosProductos) {
                    if(nombreProductoSeleccionado.equals(p.getNombreProducto())==true){
                        lstProductoDeOrdenCarrito.add(Orden.getProductoOrden(nombreProductoSeleccionado,lstTodosLosProductos));
                    }
                }
                break;
            case 2://Salir del Agregado Del Producto A Combos

                ingresoProductoOrdenCarrito = false;

                break;

            default: //Cualquier otro valor dado por el Administrador se considera inválido

                out.println("Opcion inválida");
                out.println();
                break;
        }
        return ingresoProductoOrdenCarrito;
    }
     public static boolean ejecutarAccionAgregarPromocionOrdenCarrito(int opcion,List<Promocion> lstTodasLasPromociones,List<Promocion> lstPromocinesDeCarritoOrden) throws java.io.IOException {
        Scanner sc=new Scanner(System.in);
         int opc;
        boolean ingresoPromocionOrdenCarrito = true;
        int numProd = opcion;

        switch (numProd) {

            case 1: //Opcion Ingresar en el sistema como cliente
                out.print("Ingrese el Nombre Del Producto En Promocion Que Desea Agregar.\n");
                String nombrePromocionSeleccionado=sc.next();
                for (Promocion p : lstTodasLasPromociones) {
                    if(nombrePromocionSeleccionado.equals(p.getProductoPromocion().getNombreProducto())==true){
                        lstPromocinesDeCarritoOrden.add(Promocion.getPromocionOrdenCarrito(nombrePromocionSeleccionado,lstTodasLasPromociones));
                    }
                }
                break;
            case 2://Salir del Agregado Del Producto A Combos

                ingresoPromocionOrdenCarrito = false;

                break;

            default: //Cualquier otro valor dado por el Administrador se considera inválido

                out.println("Opcion inválida");
                out.println();
                break;
        }
        return ingresoPromocionOrdenCarrito;
    }
     public static boolean ejecutarAccionAgregarComboOrdenCarrito(int opcion,List<Combo> lstTodosLosCombos,List<Combo> lstCombosDeCarritoOrden) throws java.io.IOException {
        Scanner sc=new Scanner(System.in);
         int opc;
        boolean ingresoComboOrdenCarrito = true;
        int numProd = opcion;

        switch (numProd) {

            case 1: //Opcion Agregar Combo Al Carrito De Nueva Orden
                out.print("Ingrese el Id Del Combo Que Desea Agregar.");
                String nombreIdComboSeleccionado=sc.next();
                for (Combo c : lstTodosLosCombos) {
                    if(nombreIdComboSeleccionado.equals(c.getIdCombo())==true){
                        lstCombosDeCarritoOrden.add(Combo.getComboCarrito(nombreIdComboSeleccionado, lstTodosLosCombos));
                    }
                }
                
                break;
            case 2://Salir del Agregado De Combos

                ingresoComboOrdenCarrito = false;

                break;

            default: //Cualquier otro valor dado por el Administrador se considera inválido

                out.println("Opcion inválida");
                out.println();
                break;
        }
        return ingresoComboOrdenCarrito;
    }

}


